# Data : 2023/3/6 16:31
# Author: Shawn Shi
# Right Reserved By COROS
import numpy as np
from filterpy.kalman import KalmanFilter
import matplotlib.pyplot as plt
from track_parser import track_parser, wgs_enu2lla
from raw_parser import raw_parse
from filterpy.common import Q_discrete_white_noise
from create_KML import create_kml

file = r'F:\LogData\RawData\B20\Lake\B20_6#_bd3b50.txt'

dt = 1

fv = KalmanFilter(dim_x=4, dim_z=4)
f = KalmanFilter(dim_x=4, dim_z=2)
fv.x = np.array([[0], [0], [0], [0]])  # x = [[x], [vx], [y, [vy]]
f.x = np.array([[0], [0], [0], [0]])
fv.F = np.array([[1., dt, 0, 0], [0, 1., 0, 0], [0., 0, 1, dt], [0, 0., 0, 1]])
f.F = np.array([[1., dt, 0, 0], [0, 1., 0, 0], [0., 0, 1, dt], [0, 0., 0, 1]])
fv.H = np.eye(4)
f.H = np.array([[1, 0, 0, 0], [0, 0, 1, 0]])
fv.P = np.array([[10, 2, 0, 0], [1, 10, 0, 0], [0., 0, 10, 1], [0., 0, 2, 10]])
f.P = np.array([[10, 10, 0, 0], [10, 10, 0, 0], [0., 0, 10, 10], [0., 0, 10, 10]])
a = np.ones((2, 2))
# fv.R = block_diag(a, a) * 5000
fv.R = np.array([[100, 0, 0, 0], [0, 2, 0, 0], [0, 0, 100, 0], [0, 0, 0, 2]])
f.R = np.eye(2) * 100
# f.R = np.ones((2, 2))*50
fv.Q = Q_discrete_white_noise(dim=2, dt=dt, var=0.1, block_size=2)  # dt = 1
# fv.R = fv.Q*100
f.Q = Q_discrete_white_noise(dim=2, dt=dt, var=0.1, block_size=2)
# n = 0
plt.figure()
zx = []
zy = []
fvx = []
fx = []
fvy = []
fy = []
# ##########################################################################
lsq_coord = []
kf_coord = []
# calculate velocity, vertical velocity excluded
# lsq_velocity_vector = np.zeros((1, 2))
lsq_velocity_vector = [[0, 0]]
# lsq_velocity_vector[0, :] = 0
# kf_velocity_vector = np.zeros((1, 2))
kf_velocity_vector = [[0, 0]]
# kf_velocity_vector[0, :] = 0
# Clock bias and drift
lsq_clock_bias = []
lsq_clock_drift = []
kf_clock_bias = []
kf_clock_drift = []
# calculate coordinates from velocity
# Doppler_track[:, 0, :] = 0
# kf_or_lsq, points, E_or_N
# n = 0
flow_control = False
check_checksum = True
fi = open(file[:-4] + '_Parsed raw data.txt', 'a')
with open(file, 'rb') as fo:
    data = fo.read()
    # n = n+1
    for it in raw_parse(data, flow_control, check_checksum):
        if it['kf_valid']:
            lsq_coord.extend([str(it['lsq_lon'] / 1e7), str(it['lsq_lat'] / 1e7), '0'])
            lsq_velocity_vector.append([it['lsq_horizontal_velocity_E'] / 1000,
                                        it['lsq_horizontal_velocity_N'] / 1000])
            kf_coord.extend([str(it['kf_lon'] / 1e7), str(it['kf_lat'] / 1e7), '0'])

            kf_velocity_vector.append([it['kf_horizontal_velocity_E'] / 100,
                                       it['kf_horizontal_velocity_N'] / 100])
            fi.writelines(str(it) + "\n")

        # print(it)
    # print(m)
    # print(n)
    fi.close()
    lsq_coord_data = ','.join(lsq_coord).replace(',0,', ',0 ')
    kf_coord_data = ','.join(kf_coord).replace(',0,', ',0 ')

lsq_velocity = np.array(lsq_velocity_vector)
lsq_velocity = np.delete(lsq_velocity, 0, axis=0)
kf_velocity = np.array(kf_velocity_vector)
kf_velocity = np.delete(kf_velocity, 0, axis=0)
create_kml(file[:-4] + '_lsq_track_raw', lsq_coord_data)
create_kml(file[:-4] + '_kf_track_raw', kf_coord_data)
lsq_kml = file[:-4] + '_lsq_track_raw.kml'
kf_kml = file[:-4] + '_kf_track_raw.kml'
kf_track, start_lon, start_lat = track_parser(kf_kml)
lsq_track, _, _ = track_parser(lsq_kml, start_lon, start_lat)

# ##########################################################################

for n in range(0, len(lsq_track[:, 0])):
    # zx.append(lsq_track[n, 0])
    # zy.append(lsq_track[n, 1])
    distance_diff = np.sqrt((kf_track[n, 0] - lsq_track[n, 0]) ** 2 + (kf_track[n, 1] - lsq_track[n, 1]) ** 2)

    if 0 < n < len(lsq_track[:, 0]) - 1:
        kf_previous_point = np.sqrt(kf_track[n - 1, 0] ** 2 + kf_track[n - 1, 1]**2)
        kf_current_point = np.sqrt(kf_track[n, 0] ** 2 + kf_track[n, 1]**2)
        lsq_previous_point = np.sqrt(lsq_track[n - 1, 0] ** 2 + lsq_track[n - 1, 1]**2)
        lsq_current_point = np.sqrt(lsq_track[n, 0] ** 2 + lsq_track[n, 1]**2)
        # when lsq data is not valid and kf calculated velocity is less than 10m/s (36km/h), adopt kf results
        if abs(lsq_velocity[n, 0]) < 1e-1 and abs(kf_previous_point - kf_current_point) < 10:
            fvz = np.array([[kf_track[n, 0]], [kf_velocity[n, 0]], [kf_track[n, 1]], [kf_velocity[n, 1]]])
            fz = np.array([[kf_track[n, 0]], [kf_track[n, 1]]])
        # when lsq data is valid, and difference of lsq and kf is less than 100, adopt kf results
        elif abs(lsq_velocity[n, 0]) >= 1e-1 and abs(lsq_previous_point - lsq_current_point) < 10:
            fvz = np.array([[lsq_track[n, 0]], [lsq_velocity[n, 0]], [lsq_track[n, 1]], [lsq_velocity[n, 1]]])
            fz = np.array([[lsq_track[n, 0]], [lsq_track[n, 1]]])
        # Omit results when above conditions are not met

        else:
            continue
        fv.predict()
        f.predict()
        fv.update(fvz)
        f.update(fz)
        # print(z)
        # print(f.x)
        # n = n + 1
        fvx.append(fv.x[0, 0])
        fx.append(f.x[0, 0])
        fvy.append(fv.x[2, 0])
        fy.append(f.x[2, 0])
# plt.plot(zx, zy, color='b', label='LSQ raw output')
plt.plot(kf_track[:, 0], kf_track[:, 1], color='g', label='Kalman raw output')
plt.plot(fx, fy, color='k', label='LSQ and Kf output after Kalman filtering without velocity information')
flon, flat = wgs_enu2lla(fx, fy, 0, start_lon, start_lat, 0)
coord = []
for n in range(0, len(flon)):
    coord.extend([str(flon[n]), str(flat[n]), '0'])
coord = ','.join(coord).replace(',0,', ',0 ')
create_kml(file[:-4] + '_LSQ_kalman_track_without_velocity', coord)
plt.plot(fvx, fvy, color='r', label='LSQ and Kf output after Kalman filtering with velocity information ')
fvlon, fvlat = wgs_enu2lla(fvx, fvy, 0, start_lon, start_lat, 0)
fcoord = []
for n in range(0, len(fvlon)):
    fcoord.extend([str(fvlon[n]), str(fvlat[n]), '0'])
fcoord = ','.join(fcoord).replace(',0,', ',0 ')
create_kml(file[:-4] + '_LSQ_kalman_track_with_velocity', fcoord)
plt.legend()

# do_something_with_estimate (f.x)
plt.show(block=True)
