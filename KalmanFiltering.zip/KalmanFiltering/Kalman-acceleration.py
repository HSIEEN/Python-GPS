# Data : 2023/3/6 16:31
# Author: Shawn Shi
# Right Reserved By COROS
import numpy as np
from filterpy.kalman import KalmanFilter
import matplotlib.pyplot as plt
from track_parser import track_parser
from filterpy.common import Q_discrete_white_noise

dt = 1
lsq_kml = r'F:\LogData\RawData\B20\log_system_92548f-clear_lsq_track.kml'
kf_kml = lsq_kml.replace('lsq', 'kf')
lsq_velocity = np.loadtxt(lsq_kml.replace('track.kml', 'velocity.txt'))
# kf_velocity = np.loadtxt(lsq_kml.replace('lsq_track.kml', 'kf_velocity.txt'))

lsq_track, start_lon, start_lat = \
    track_parser(lsq_kml)
kf_track, _, _ = track_parser(lsq_kml.replace('lsq', 'kf'), start_lon, start_lat)
fv = KalmanFilter(dim_x=6, dim_z=4)
f = KalmanFilter(dim_x=6, dim_z=2)
fv.x = np.array([[0], [0], [0], [0], [0], [0]])  # x = [[x], [vx], [ax], [y], [vy], [ay]]
f.x = np.array([[0], [0], [0], [0], [0], [0]])
fv.F = np.array([[1., dt, 0.5 * dt ** 2, 0, 0, 0],
                 [0, 1., dt, 0, 0, 0],
                 [0., 0, 1, 0, 0, 0],
                 [0, 0., 0, 1, dt, 0.5 * dt ** 2],
                 [0, 0, 0, 0, 1, dt],
                 [0, 0, 0, 0, 0, 1]])
f.F = np.array([[1., dt, 0.5 * dt ** 2, 0, 0, 0],
                [0, 1., dt, 0, 0, 0],
                [0., 0, 1, 0, 0, 0],
                [0, 0., 0, 1, dt, 0.5 * dt ** 2],
                [0, 0, 0, 0, 1, dt],
                [0, 0, 0, 0, 0, 1]])
fv.H = np.array([[1, 0, 0, 0, 0, 0],
                 [0, 1, 0, 0, 0, 0],
                 [0, 0, 0, 1, 0, 0],
                 [0, 0, 0, 0, 1, 0]])
f.H = np.array([[1, 0, 0, 0, 0, 0], [0, 0, 0, 1, 0, 0]])
fv.P = np.array([[100, 100, 100, 0, 0, 0],
                 [100, 100, 100, 0, 0, 0],
                 [100, 100, 100, 0, 0, 0],
                 [0., 0, 0, 100, 100, 100],
                 [0., 0, 0, 100, 100, 100],
                 [0., 0, 0, 100, 100, 100]])
f.P = np.array([[100, 100, 100, 0, 0, 0],
                [100, 100, 100, 0, 0, 0],
                [100, 100, 100, 0, 0, 0],
                [0., 0, 0, 100, 100, 100],
                [0., 0, 0, 100, 100, 100],
                [0., 0, 0, 100, 100, 100]])
# fv.R = block_diag(a, a) * 5000
fv.R = np.array([[100, 0, 0, 0], [0, 1, 0, 0], [0, 0, 100, 0], [0, 0, 0, 1]])
f.R = np.eye(2) * 50
# f.R = np.ones((2, 2))*50
fv.Q = Q_discrete_white_noise(dim=3, dt=dt, var=0.5, block_size=2)  # dt = 1
# fv.R = fv.Q*100
f.Q = Q_discrete_white_noise(dim=3, dt=dt, var=0.6, block_size=2)
n = 0
plt.figure()
zx = []
zy = []
fvx = []
fx = []
fvy = []
fy = []
for n in range(1, len(lsq_track[:, 0])):
    zx.append(lsq_track[n, 0])
    zy.append(lsq_track[n, 1])
    fvz = np.array([[lsq_track[n, 0]], [lsq_velocity[n, 0]], [lsq_track[n, 1]], [lsq_velocity[n, 1]]])
    fz = np.array([[lsq_track[n, 0]], [lsq_track[n, 1]]])
    fv.predict()
    f.predict()
    fv.update(fvz)
    f.update(fz)
    # print(z)
    # print(f.x)
    # n = n + 1
    fvx.append(fv.x[0, 0])
    fx.append(f.x[0, 0])
    fvy.append(fv.x[3, 0])
    fy.append(f.x[3, 0])
plt.plot(zx, zy, color='b', label='LSQ raw output')
plt.plot(kf_track[:, 0], kf_track[:, 1], color='g', label='Kalman raw output')
plt.plot(fx, fy, color='k', label='LSQ output after Kalman filtering without velocity information')
plt.plot(fvx, fvy, color='r', label='LSQ output after Kalman filtering with velocity information ')
plt.legend()

# do_something_with_estimate (f.x)
plt.show(block=True)
