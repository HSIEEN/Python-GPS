#! /usr/bin/env python
# -*- coding=utf-8 -*-
import os, glob
from tokenize import Ignore
from DecodeGsv import gsv_data
from CreateExcel import create_excel

nema_file, snr_file, reset_close, file_list = "", "", False, []


def gps_ori_data(file_path):
    """原始GPS数据，提取经纬度信息写入kml文件"""
    lon_lat = []
    with open(file_path, 'r', encoding='utf-8', errors="ignore") as fp:
        for line in fp:
            if "GNRMC" in line:
                data = line.split(",")
                try:
                    if data[3] != '0.000000' and data[5] != '0.000000' and data[3] != "":
                        if data[4] == "N":
                            LAT_NUM = 1
                        elif data[4] == "S":
                            LAT_NUM = -1
                        else:
                            continue
                        if data[6] == "E":
                            LON_NUM = 1
                        elif data[6] == "W":
                            LON_NUM = -1
                        else:
                            continue

                        lon_lat.append(str((int(float(data[5]) / 100) + (float(data[5]) % 100) / 60) * LON_NUM))
                        lon_lat.append(str((int(float(data[3]) / 100) + (float(data[3]) % 100) / 60) * LAT_NUM))
                        lon_lat.append('0')
                except Exception as e:
                    print(e)
    gps_data = ','.join(lon_lat).replace(',0,', ',0 ')
    return gps_data


def read_data(gps_data, file_kml, path):
    """传入经纬度信息写入kml文件，区分原始数据与算法处理过的数据"""
    with open(file_kml, 'r', encoding='utf-8') as fp:
        lines = fp.readlines()
    for i in range(len(lines) - 1):
        if '<coordinates>' in lines[i]:
            lines[i] = '<coordinates>' + gps_data + '</coordinates>\n'
    with open(path, 'w', encoding='utf-8') as f:
        f.writelines(lines)


def create_kml(time_name):
    if os.path.exists("./nema_file/%s_NEMA.txt" % time_name):
        gps_data = gps_ori_data("./nema_file/%s_NEMA.txt" % time_name)
        if len(gps_data):
            read_data(gps_data, "gps_ori_data.kml", "./kml_file/%s.kml" % time_name)


def extract_data():
    global nema_file, snr_file, reset_close, file_list
    data_file = glob.glob("*.txt")
    for f in data_file:
        chip_type = get_chip_type(f)
        data_file_name = f.split(".txt")[0]
        write_data = False
        with open(f, 'r', encoding="utf-8", errors='ignore') as fp:
            for line in fp:
                if line.startswith("NEMA:start_time:") or line.startswith("GPS_LOG:start_time:"):
                    if reset_close:
                        nema_file.close()
                        snr_file.close()
                        reset_file()
                        create_kml(time_name)
                    time_name = line.split("start_time:")[1].replace("/", "_").replace(":", "_").strip("\n").split()
                    time_name = data_file_name + "_" + time_name[0] + " " + time_name[1]
                    write_data = True  # start time后的才开始写数据

                if write_data:  # 首次写入确保start time存在
                    reset_close = True
                    if nema_file == "":
                        nema_file = open("./nema_file/%s_NEMA.txt" % time_name, "w", encoding="utf-8")
                        snr_file = open("./snr_file/%s_SNR.txt" % time_name, "w", encoding="utf-8")
                    nema_file.write(line.strip("NEMA:").strip("GPS_LOG:"))
                    gsv_data(line, snr_file, chip_type)
        if reset_close:  # 判断是否是最后一组文件数据
            nema_file.close()
            snr_file.close()
            reset_file()
            create_kml(time_name)


def reset_file():
    global nema_file, snr_file, reset_close, file_list
    nema_file = ""
    snr_file = ""
    reset_close = False
    file_list = []


def mkdir_file(file_list):
    for file_path in file_list:
        # 删除 文件夹下所有文件
        for file in glob.glob('./%s/*' % file_path):
            os.remove(file)
        if not os.path.exists(file_path):
            os.mkdir(file_path)


def del_emp_dir(path):
    for (root, dirs, files) in os.walk(path):
        for item in dirs:
            dir = os.path.join(root, item)
            try:
                os.rmdir(dir)
            except Exception as e:
                pass


def get_chip_type(filepath):
    with open(filepath, "r", encoding="utf-8", errors="ignore") as fp:
        lines = fp.readlines()
        for line in lines[0:200] if len(lines) > 200 else lines:
            if "$PSGSA" in line:
                return "sony"
    return "mtk"


if __name__ == "__main__":
    file_list = ['kml_file', 'nema_file', 'snr_file', 'binary_file']
    mkdir_file(file_list)
    extract_data()
    del_emp_dir("./")
    file_name = create_excel()
    input("执行完毕!生成文件:%s" % file_name)
