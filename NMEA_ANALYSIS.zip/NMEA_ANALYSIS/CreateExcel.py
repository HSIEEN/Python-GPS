#! /usr/bin/env python
# -*- coding=utf-8 -*-

import os, random
import xlsxwriter

excel_name = {
    6: "G",
    7: "H",
    8: "I",
    9: "J",
    10: "K",
    11: "L",
    12: "M",
    13: "N",
    14: "O",
    15: "P",
    16: "Q",
    17: "R",
    18: "S",
    19: "T",
    20: "U",
    21: "V",
    22: "W",
    23: "X",
    24: "Y",
    25: "Z",
    26: "AA",
    27: "AB",
    28: "AC",
    29: "AD",
    30: "AE",
    31: "AF",
    32: "AG",
    33: "AH",
    34: "AI",
    35: "AJ",
    36: "AK",
    37: "AL",
    38: "AM",
    39: "AN",
    40: "AO",
    41: "AP",
    42: "AQ",
    43: "AR",
    44: "AS",
    45: "AT",
    46: "AU",
    47: "AV",
    48: "AW",
}
type_gps = ["#GSNR_L1", "#GSNR_L5", "#LSNR_L1", "#LSNR_L5", "#BSNR_L1", "#BSNR_L5", "#ASNR_L1",
            "#ASNR_L5"]  # ,"QSNR_L1","QSNR_L5"

SATE_INI = {}
COUNT_INI = {}


def ini_data():
    global SATE_INI, COUNT_INI
    # 清除统计信息
    SATE_INI = {
        "#GSNR_L1": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#GSNR_L5": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#LSNR_L1": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#LSNR_L5": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#BSNR_L1": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#BSNR_L5": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#ASNR_L1": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#ASNR_L5": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#QSNR_L1": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#QSNR_L5": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        }
    }

    COUNT_INI = {
        "#GSNR_L1": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#GSNR_L5": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#LSNR_L1": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#LSNR_L5": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#BSNR_L1": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#BSNR_L5": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#ASNR_L1": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#ASNR_L5": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#QSNR_L1": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        },
        "#QSNR_L5": {
            "SNR_4": 0,
            "ACTUAL_4": 0,
            "ACTUAL_ALL": 0,
            "VIEW": 0,
            "SNR": 0,
            "ACTUAL": 0,
        }
    }


def create_excel():
    global SATE_INI, COUNT_INI
    if not os.path.exists("./snr_file"):
        return
    xls_name = 'snr_data_%s.xls' % random.randint(0, 9)
    workbook = xlsxwriter.Workbook(xls_name)
    worksheet = workbook.add_worksheet("chart")  # 创建一个工作表对象

    # 删除空文件
    for file in os.listdir("./snr_file"):
        size = os.path.getsize("./snr_file/%s" % file)
        if size == 0:
            os.remove('./snr_file/%s' % file)

    files = os.listdir("./snr_file")
    files_len = len(files)
    for i in range(len(type_gps)):
        worksheet.write(i * (files_len + 1), 0, "样机编号")
        worksheet.write(i * (files_len + 1), 1, "%s_4_CN平均值" % type_gps[i])
        worksheet.write(i * (files_len + 1), 2, "%s_4定位卫星平均值" % type_gps[i].split("SNR_")[1])
        worksheet.write(i * (files_len + 1), 3, "%s_定位卫星平均值" % type_gps[i].split("SNR_")[1])
        worksheet.write(i * (files_len + 1), 4, "%s_可视卫星数" % type_gps[i].split("SNR_")[1])
        worksheet.write(i * (files_len + 1), 5, "%s_CN值卫星数" % type_gps[i].split("SNR_")[1])
        worksheet.write(i * (files_len + 1), 6, "%s_定位卫星数" % type_gps[i].split("SNR_")[1])
        worksheet.write(0, 7, "L1总定位卫星数")
        worksheet.write(0, 8, "L5总定位卫星数")
        worksheet.write(0, 9, "L1_6可见卫星平均值")
        worksheet.write(0, 10, "L5_4可见卫星平均值")
        worksheet.write(0, 11, "L1_6参与定位平均值")
        worksheet.write(0, 12, "L5_4参与定位平均值")
    col = 15
    nrows = []  # 存储每个数据文件的行数大小
    for i in range(files_len):
        gsnr_count = 0
        ini_data()
        L1_L5_count = [0, 0, 0, 0]  # snr_L1_avg_6,snr_L5_avg_4,actual_L1_avg_6,actual_L5_avg_4,
        L1_L5_avg = [0, 0, 0, 0]
        with open("./snr_file/%s" % files[i]) as fp:
            data = fp.readlines()
            file_name = files[i].strip("_SNR.txt")
            for k in range(len(data)):
                snr_avg_4 = float(data[k].split("snr_avg_4:")[1].split(",")[0])
                actual_avg_4 = float(data[k].split("actual_avg_4:")[1].split(",")[0])
                actual_avg = float(data[k].split("actual_avg:")[1].split(",")[0])
                VIEW = float(data[k].split("view:")[1].split(",")[0])
                SNR = float(data[k].split("snr:")[1].split(",")[0])
                ACTUAL = float(data[k].split("actual:")[1].split(",")[0])
                snr_L1_avg_6 = float(data[k].split("snr_L1_avg_6:")[1].split(",")[0])
                snr_L5_avg_4 = float(data[k].split("snr_L5_avg_4:")[1].split(",")[0])
                actual_L1_avg_6 = float(data[k].split("actual_L1_avg_6:")[1].split(",")[0])
                actual_L5_avg_4 = float(data[k].split("actual_L5_avg_4:")[1].split(",")[0])
                if snr_L1_avg_6 != 0:
                    L1_L5_count[0] += 1
                    L1_L5_avg[0] += snr_L1_avg_6
                if snr_L5_avg_4 != 0:
                    L1_L5_count[1] += 1
                    L1_L5_avg[1] += snr_L5_avg_4
                if actual_L1_avg_6 != 0:
                    L1_L5_count[2] += 1
                    L1_L5_avg[2] += actual_L1_avg_6
                if actual_L5_avg_4 != 0:
                    L1_L5_count[3] += 1
                    L1_L5_avg[3] += actual_L5_avg_4

                gps_tag = data[k][0:8]
                if snr_avg_4 != 0:
                    COUNT_INI[gps_tag]["SNR_4"] += 1
                    SATE_INI[gps_tag]["SNR_4"] += snr_avg_4
                if actual_avg_4 != 0:
                    COUNT_INI[gps_tag]["ACTUAL_4"] += 1
                    SATE_INI[gps_tag]["ACTUAL_4"] += actual_avg_4
                if actual_avg != 0:
                    COUNT_INI[gps_tag]["ACTUAL_ALL"] += 1
                    SATE_INI[gps_tag]["ACTUAL_ALL"] += actual_avg
                if VIEW != 0:
                    COUNT_INI[gps_tag]["VIEW"] += 1
                    SATE_INI[gps_tag]["VIEW"] += VIEW
                if SNR != 0:
                    COUNT_INI[gps_tag]["SNR"] += 1
                    SATE_INI[gps_tag]["SNR"] += SNR
                if ACTUAL != 0:
                    COUNT_INI[gps_tag]["ACTUAL"] += 1
                    SATE_INI[gps_tag]["ACTUAL"] += ACTUAL
                if gps_tag == "#GSNR_L1":  # 只统计GPS L1
                    gsnr_count += 1
                    worksheet.write(gsnr_count, col, actual_avg_4)
                    worksheet.write(0, col, file_name)

        col += 1
        nrows.append(gsnr_count)
        L1_sate_count = 0
        L5_sate_count = 0
        for k in range(len(type_gps)):
            if "_L1" in type_gps[k] and COUNT_INI[type_gps[k]]["ACTUAL"] != 0:  # 统计L1星座总参与定位卫星个数
                L1_sate_count += round(float(SATE_INI[type_gps[k]]["ACTUAL"] / COUNT_INI[type_gps[k]]["ACTUAL"]), 2)
            if "_L5" in type_gps[k] and COUNT_INI[type_gps[k]]["ACTUAL"] != 0:  # 统计L5星座总参与定位卫星个数
                L5_sate_count += round(float(SATE_INI[type_gps[k]]["ACTUAL"] / COUNT_INI[type_gps[k]]["ACTUAL"]), 2)
            worksheet.write(i + k * (files_len + 1) + 1, 0, file_name)
            if COUNT_INI[type_gps[k]]["SNR_4"] != 0:
                worksheet.write(i + k * (files_len + 1) + 1, 1,
                                round(float(SATE_INI[type_gps[k]]["SNR_4"] / COUNT_INI[type_gps[k]]["SNR_4"]), 2))
            else:
                worksheet.write(i + k * (files_len + 1) + 1, 1, 0)
            if COUNT_INI[type_gps[k]]["ACTUAL_4"] != 0:
                worksheet.write(i + k * (files_len + 1) + 1, 2,
                                round(float(SATE_INI[type_gps[k]]["ACTUAL_4"] / COUNT_INI[type_gps[k]]["ACTUAL_4"]), 2))
            else:
                worksheet.write(i + k * (files_len + 1) + 1, 2, 0)
            if COUNT_INI[type_gps[k]]["ACTUAL_ALL"] != 0:
                worksheet.write(i + k * (files_len + 1) + 1, 3,
                                round(float(SATE_INI[type_gps[k]]["ACTUAL_ALL"] / COUNT_INI[type_gps[k]]["ACTUAL_ALL"]),
                                      2))
            else:
                worksheet.write(i + k * (files_len + 1) + 1, 3, 0)
            if COUNT_INI[type_gps[k]]["VIEW"] != 0:
                worksheet.write(i + k * (files_len + 1) + 1, 4,
                                round(float(SATE_INI[type_gps[k]]["VIEW"] / COUNT_INI[type_gps[k]]["VIEW"]), 2))
            else:
                worksheet.write(i + k * (files_len + 1) + 1, 4, 0)
            if COUNT_INI[type_gps[k]]["SNR"] != 0:
                worksheet.write(i + k * (files_len + 1) + 1, 5,
                                round(float(SATE_INI[type_gps[k]]["SNR"] / COUNT_INI[type_gps[k]]["SNR"]), 2))
            else:
                worksheet.write(i + k * (files_len + 1) + 1, 5, 0)
            if COUNT_INI[type_gps[k]]["ACTUAL"] != 0:
                worksheet.write(i + k * (files_len + 1) + 1, 6,
                                round(float(SATE_INI[type_gps[k]]["ACTUAL"] / COUNT_INI[type_gps[k]]["ACTUAL"]), 2))
            else:
                worksheet.write(i + k * (files_len + 1) + 1, 6, 0)
        worksheet.write(i + 1, 7, L1_sate_count)
        worksheet.write(i + 1, 8, L5_sate_count)
        worksheet.write(i + 1, 9, round(L1_L5_avg[0] / L1_L5_count[0], 2) if L1_L5_count[0] != 0 else 0)
        worksheet.write(i + 1, 10, round(L1_L5_avg[1] / L1_L5_count[1], 2) if L1_L5_count[1] != 0 else 0)
        worksheet.write(i + 1, 11, round(L1_L5_avg[2] / L1_L5_count[2], 2) if L1_L5_count[2] != 0 else 0)
        worksheet.write(i + 1, 12, round(L1_L5_avg[3] / L1_L5_count[3], 2) if L1_L5_count[3] != 0 else 0)

    offset = 8  # 定义图表偏移量
    chart = workbook.add_chart({'type': 'line'})
    chart.set_size({'width': 800, 'height': 350})
    chart.set_title({'name': '参与定位avg4平均值'})
    col = 15
    for j in range(len(nrows)):
        chart.add_series({'name': files[j].strip('_SNR.txt'),
                          'values': '=chart!$%s$2:$%s$%s' % (excel_name[col + j], excel_name[col + j], nrows[j])})
    worksheet.insert_chart('J%s' % (i + offset), chart)  # 插入数据图表
    workbook.close()
    return xls_name


if __name__ == "__main__":
    create_excel()
