#! /usr/bin/env python
# -*- coding=utf-8 -*-


SATE_VIEW,SATE_SNR,SATE_ACTUAL,SATE_NUMBER,actual_sate = {},{},{},{},{}

SATE_TYPE = {"1":"GSNR","2":"LSNR","3":"ASNR","4":"BSNR","5":"GSNR"}

def ini_data():
    global SATE_VIEW,SATE_SNR,SATE_ACTUAL,SATE_NUMBER,actual_sate
    actual_sate = {"GSNR":[],"LSNR":[],"ASNR":[],"BSNR":[]}
    SATE_VIEW = {
        "GSNR_L1":0,
        "GSNR_L5":0,
        "LSNR_L1":0,
        "LSNR_L5":0,
        "BSNR_L1":0,
        "BSNR_L5":0,
        "ASNR_L1":0,
        "ASNR_L5":0
        }
    SATE_SNR = {
        "GSNR_L1":{},
        "GSNR_L5":{},
        "LSNR_L1":{},
        "LSNR_L5":{},
        "BSNR_L1":{},
        "BSNR_L5":{},
        "ASNR_L1":{},
        "ASNR_L5":{}
        }
    SATE_ACTUAL = {
        "GSNR_L1":{},
        "GSNR_L5":{},
        "LSNR_L1":{},
        "LSNR_L5":{},
        "BSNR_L1":{},
        "BSNR_L5":{},
        "ASNR_L1":{},
        "ASNR_L5":{}
        }
    SATE_NUMBER = {
        "GSNR_L1":[],
        "GSNR_L5":[],
        "LSNR_L1":[],
        "LSNR_L5":[],
        "BSNR_L1":[],
        "BSNR_L5":[],
        "ASNR_L1":[],
        "ASNR_L5":[]
        }

ini_data()

def gsv_data(line,snr_file,chip_type):
    global SATE_VIEW
    sate_num = 0 
    if "$" in line and "GSV" in line:
        if not nema_checksum(line):
            return
        GSV_data = line.split(",")
        try:
            sate_num = int(GSV_data[3]) # 可视卫星个数
            freq = GSV_data[-1].split("*")[0]
            L_num = 5 if int(freq) > 1 else 1
        except Exception as e:
            return
            
    if "$GPGSV" in line: # GPS
        SATE_VIEW["GSNR_L%s" %L_num] = sate_num
        decode_gsv_data("GSNR_L%s" %L_num,sate_num,GSV_data)
    elif "$GLGSV" in line: # GLONASS
        SATE_VIEW["LSNR_L%s" %L_num] = sate_num
        decode_gsv_data("LSNR_L%s" %L_num,sate_num,GSV_data)
    elif "$GBGSV" in line or "$BDGSV" in line: # Beidou
        SATE_VIEW["BSNR_L%s" %L_num] = sate_num
        decode_gsv_data("BSNR_L%s" %L_num,sate_num,GSV_data)
    elif "$GAGSV" in line: # Galileo
        if chip_type == "mtk":
            L_num = 1 if int(freq) > 1 else 5
        SATE_VIEW["ASNR_L%s" %L_num] = sate_num
        decode_gsv_data("ASNR_L%s" %L_num,sate_num,GSV_data)
    elif "$GQGSV" in line: # QZSS 目前全部统计在GPS下
        SATE_VIEW["GSNR_L%s" %L_num] += sate_num
        decode_gsv_data("GSNR_L%s" %L_num,sate_num,GSV_data)

    if "GSA" in line: # 实际参与定位卫星编号的位置
        try:
            if line.split(",")[-1].split("*")[0] != "":
                actual_sate[SATE_TYPE[line.split(",")[-1].split("*")[0]]] += [i for i in line.split(",")[3:15] if i != '']
        except Exception as e:
            print(e)
    if "RMC" in line: # nema结束语句
        get_actual_sate()
        write_data(snr_file)
        ini_data()


def decode_gsv_data(data_type,sate_num,GSV_data):
    """解析GSV语句，获取卫星信号值及卫星编号"""
    global SATE_SNR,SATE_NUMBER
    if int(sate_num) != 0: # view sate不为零
        for i in range(int((len(GSV_data) - 4)/4)): # 提取SNR数据 -- NEMA:$GLGSV,,1,05,71,60,112,30,72,29,177,27,85,29,056,26,76,28,266,20,1*7F
            snr = GSV_data[7:][i*4]
            if snr != "" and snr != "00":
                try:
                    snr = int(snr)
                except Exception as e:
                    continue
                if snr > 100: # 过滤异常解析数据:00 - 99dB
                    continue
                SATE_SNR[data_type][GSV_data[4:][i*4]] = snr
                SATE_NUMBER[data_type].append(GSV_data[4:][i*4])

def write_data(snr_file):
    """统计卫星个数及平均值"""
    global SATE_VIEW,SATE_SNR,SATE_ACTUAL
    snr_avg_4 = 0
    actual_avg_4 = 0
    actual_avg = 0
    snr_L1_avg_6 = 0 #  SNR L1前6颗星
    snr_L5_avg_4 = 0 #   SNR L5前4颗星
    actual_L1_avg_6 = 0
    actual_L5_avg_4 = 0
    for key,value in SATE_VIEW.items():
        snr = sorted(SATE_SNR[key].values(),reverse = True)
        actual = sorted(SATE_ACTUAL[key].values(),reverse = True)
        # 只统计L1前6颗星和L5前4颗星的均值，不考虑星座。分可见和参与定位两种
        if "L1" in key:
            if len(snr) >= 6:
                snr_L1_avg_6 = round(sum(snr[0:6])/6,2)  
            if len(snr) < 6 and len(snr) > 0:
                snr_L1_avg_6 = round(sum(snr)/len(snr),2)
            if len(actual) >= 6:
                actual_L1_avg_6 = round(sum(actual[0:6])/6,2)  
            if len(actual) < 6 and len(actual) > 0:
                actual_L1_avg_6 = round(sum(actual)/len(actual),2)
        if "L5" in key:
            if len(snr) >= 4:
                snr_L5_avg_4 = round(sum(snr[0:4])/4,2)  
            if len(snr) < 4 and len(snr) > 0:
                snr_L5_avg_4 = round(sum(snr)/len(snr),2)
            if len(actual) >= 4:
                actual_L5_avg_4 = round(sum(actual[0:4])/4,2)  
            if len(actual) < 4 and len(actual) > 0:
                actual_L5_avg_4 = round(sum(actual)/len(actual),2)
        if len(snr) >= 5:
            snr_avg_4 = round(sum(snr[0:4])/4,2)
        if len(snr) < 5 and len(snr) > 0: # 按实际卫星个数计算
            snr_avg_4 = round(sum(snr)/len(snr),2) # 低于4颗卫星计算平均值时按4颗求平均

        actual_avg = round(sum(actual)/len(actual),2) if len(actual) != 0 else 0
        if len(actual) >= 5:
            actual_avg_4 = round(sum(actual[0:4])/4,2)
        if len(actual) < 5 and len(actual) > 0:
            actual_avg_4 = round(sum(actual)/len(actual),2)

        snr_str = " ".join([str(i) for i in snr]) if snr != [] else ""
        actual_str = " ".join([str(i) for i in actual]) if actual != [] else ""
        if value != 0: # view sate 不为零
            snr_file.write("#%s,view:%d,snr:%d,actual:%d,snr_avg_4:%s,actual_avg_4:%s,actual_avg:%s,snr_str:%s,actual_str:%s,snr_L1_avg_6:%s,snr_L5_avg_4:%s,actual_L1_avg_6:%s,actual_L5_avg_4:%s\n" \
                %(key,value,len(snr),len(actual),snr_avg_4,actual_avg_4,actual_avg,snr_str,actual_str,snr_L1_avg_6,snr_L5_avg_4,actual_L1_avg_6,actual_L5_avg_4))

def get_actual_sate():
    """判断实际参与卫星属于哪个星座"""
    global SATE_ACTUAL,SATE_NUMBER,SATE_SNR,actual_sate
    for key,value in SATE_NUMBER.items():
        for sate in actual_sate[key.split("_")[0]]:
            if sate in value:
                SATE_ACTUAL[key][sate] = SATE_SNR[key][sate]


def nema_checksum(nema_data):
    check_sum = None
    result = 0
    try:
        check_sum = int(nema_data.split("*")[1],16)
        nema_data = nema_data.split("$")[1].split("*")[0].encode("utf-8")
        result = nema_data[0]
        for i in nema_data[1:]:
            result ^= i
    except Exception as e:
        print(e)
    if result == check_sum:
        return True
    return False

#print(nema_checksum("$GPGSV,3,1,11,10,67,176,37,194,65,085,22,193,60,101,20,199,59,149,,1*5E"))