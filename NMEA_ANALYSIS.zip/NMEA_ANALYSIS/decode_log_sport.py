# coding:utf-8
import glob
import binascii


def decode_data1(file_name):
    crc = 0
    for data in file_name.split("log_sport_")[1].split('.dat')[0][0:6]:
        crc += ord(data)
    crc = crc&0xff
    print(crc)
    with open(file_name,"rb") as fp:
        data = fp.read()
    file = open("%s.txt" %file_name.split('.dat')[0],'w',encoding='utf-8')
    for i in data:
        try:
            file.write(chr((i)^crc))
            
        except Exception as e:
            print(e)
    file.close()
    
if __name__=="__main__":
    for file in glob.glob("./log_sport_*.dat"):
        decode_data1(file)