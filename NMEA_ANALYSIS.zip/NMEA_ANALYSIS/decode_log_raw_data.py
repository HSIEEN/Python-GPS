# coding:utf-8
import glob, re
import os


def cal_crc(data_type):
    crc = 0
    for data in data_type.split("_")[1]:
        crc += ord(data)
    crc = crc & 0xff
    return crc


def parse_byte_data(bin_data, crc, split_str):
    parse_data = ""
    for i in bin_data:
        parse_data += chr(i)
    startswith = "logtime"
    if "system_" in split_str:
        startswith = "start_time"
    if parse_data.startswith(startswith):
        utc_time = re.findall(r"(\d{4}-\d{1,2}-\d{1,2}\s\d{1,2}:\d{1,2}:\d{1,2})", parse_data)[0].replace(":",
                                                                                                          "_").replace(
            " ", "_")
        return utc_time
    return False


def decode_log_data(file_name, file_result, data_type):
    crc = cal_crc(data_type)
    with open(file_name, "rb") as fp:
        data = fp.read()
    print(data_type)
    for i in range(len(data)):
        try:
            # 文件数据分段
            utc_time = parse_byte_data(data[i:i + 40], crc, data_type)
            if utc_time:
                file_result.close()
                file_result = open(r"./binary_file\%s_%s.txt" % (file_name.split('.txt')[0], utc_time), 'wb')
            if "sport" in data_type:
                file_result.write(chr(data[i]).encode())
            if "system" in data_type:
                file_result.write((data[i]).to_bytes(1, byteorder="big", signed=False))
        except Exception as e:
            print(e)
    file_result.close()


if __name__ == "__main__":
    deviceid_files = {}
    for file in glob.glob("./log_*.txt"):
        key = file.split("_")[1] + "_" + file.split("_")[2].split(".txt")[0]
        if key not in deviceid_files.keys():
            deviceid_files[key] = [file]
        else:
            deviceid_files[key].append(file)
    if not os.path.exists(r'./binary_file'):
        os.mkdir(r'./binary_file')
    for data_type, files in deviceid_files.items():
        file_result = open(r"%s.txt" % data_type, 'wb')
        for file in sorted(files, reverse=True):
            decode_log_data(file, file_result, data_type)
        file_result.close()
