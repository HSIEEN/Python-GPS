# Data : 2023/1/5 19:50
# Author: Shawn Shi
# Right Reserved By COROS
import numpy as np
from track_length import track_length


def shift_evaluate3(std, track):
    # ssd = track.shape
    len_std = track_length(std)
    len_trk = track_length(track)
    # weighted average by distance around a point
    Csx, Csy = 0.0, 0.0
    for i in range(1, len(std)-1):
        x0 = std[i-1][0]
        y0 = std[i-1][1]
        x1 = std[i][0]
        y1 = std[i][1]
        x2 = std[i+1][0]
        y2 = std[i+1][1]
        weight = (np.sqrt((x0-x1)**2+(y0-y1)**2)+np.sqrt((x1-x2)**2+(y1-y2)**2))/(2*len_std)
        Csx = Csx + x1*weight
        Csy = Csy + y1*weight
    Ctx, Cty = 0.0, 0.0
    for i in range(1, len(track) - 1):
        x0 = track[i-1][0]
        y0 = track[i-1][1]
        x1 = track[i][0]
        y1 = track[i][1]
        x2 = track[i+1][0]
        y2 = track[i+1][1]
        weight = (np.sqrt((x0 - x1) ** 2 + (y0 - y1) ** 2) + np.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)) / (2 * len_trk)
        Ctx = Ctx + x1 * weight
        Cty = Cty + y1 * weight
    # test track center
    shift = [Ctx-Csx, Cty-Csy]

    return shift
