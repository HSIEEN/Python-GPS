import numpy as np


def HausdorffDist(P=None, Q=None):
    # p: standard, Q: measured
    sP = P.shape
    sQ = Q.shape
    if not (sP[1] == sQ[1]):
        raise Exception('Inputs P and Q must have the same number of columns')

    shift_vector = np.zeros((sQ[0], 2))
    n = 0
    mq = np.zeros((sQ[0], 1))
    ixq = np.ones((sQ[0], 1))
    for i in range(0, sQ[0]):
        mq[i] = 10000000000.0
        for j in range(0, sP[0]):
            dist = np.sqrt(sum((Q[i, :] - P[j, :]) ** 2))
            if mq[i] > dist:
                mq[i] = dist
                ixq[i] = j
                shift_vector[i, :] = Q[i, :] - P[j, :]

    # shift vector calculation
    average_shift_vector = np.average(shift_vector, axis=0)
    # average Hausdorff distance
    vq = np.mean(mq)

    # Hausdorff distance in definition
    maxq = np.amax(mq)

    return maxq, vq, average_shift_vector
