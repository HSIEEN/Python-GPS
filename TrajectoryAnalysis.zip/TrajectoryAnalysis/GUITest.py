# Data : 2023/1/6 16:01
# Author: Shawn Shi
# Right Reserved By COROS
from tkinter.simpledialog import askinteger
import tkinter as tk

root = tk.Tk()
root.withdraw()
prompt = askinteger("Input", "Input an Integer")
print(prompt)

# root.mainloop()
