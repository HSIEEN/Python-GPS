# Data : 12/29/2022 5:07 PM
# Author: Shawn Shi
# Right Reserved By COROS
import numpy as np


def track_length(track):
    length = 0
    for i in range(1, len(track)):
        delta = np.sqrt((track[i][0] - track[i - 1][0]) ** 2 + (track[i][1] - track[i - 1][1]) ** 2)
        if delta > 0.3:
            length = length + delta
    return length

