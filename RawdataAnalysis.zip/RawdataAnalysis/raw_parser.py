# Data : 2023/3/15 15:15
# Author: Shawn Shi
# Right Reserved By COROS

import struct
import sys
import numpy as np
import math


def calc_checksum(checksum_range: bytes) -> int:
    checksum_calc = checksum_range[0]
    for it in checksum_range[1:]:
        checksum_calc ^= it
    return checksum_calc


def convert_flow_control(data: bytes) -> bytes:
    converted_bytes = bytearray()
    need_convert = False
    for it in data:
        if need_convert:
            converted_bytes.append(0xff - it)
            need_convert = False
            continue
        if it == 0x77:
            need_convert = True
            continue
        converted_bytes.append(it)
    return converted_bytes


def raw_parse(data: bytes, flow_control=True, check_checksum=True):
    preamble = b'\x04\x24'
    end = b'\xAA\x44'
    start_pos = 0
    checksum_error_cnt = 0
    while True:
        start_pos = data.find(preamble, start_pos)
        if start_pos == -1:
            break
        end_pos = data.find(end, start_pos)
        if end_pos == -1:
            break

        message_bytes = data[start_pos:end_pos + 2]
        start_pos = end_pos + 2

        if not message_bytes:
            continue

        if flow_control:
            message_bytes = convert_flow_control(message_bytes)

        if check_checksum:
            checksum_calc = calc_checksum(message_bytes[2:-3])  # message_bytes[2:-3]
            if checksum_calc != message_bytes[-3]:
                checksum_error_cnt += 1
                continue

        message_id = struct.unpack('<H', message_bytes[2:4])[0]
        if message_id != 4005:
            continue
        length = int.from_bytes(message_bytes[4:6], byteorder='little')
        msg_data = message_bytes[6:6 + length]
        if len(msg_data) != 120:
            continue

        datadict = {}
        (
            datadict['iod'],  # U1
            datadict['fix_type'],  # U1
            datadict['year'],  # U2
            datadict['month'],  # U1
            datadict['day'],  # U1
            datadict['hour'],  # U1
            datadict['minute'],  # U1
            datadict['ms'],  # U2
            datadict['second'],  # U1
            pvt_status,  # U1,
            datadict['lat'],  # I4
            datadict['lon'],  # I4
            datadict['alt'],  # I4
            datadict['geoid'],  # I4
            datadict['speed'],  # U4
            datadict['heading'],  # U4
            datadict['horizontal_accuracy'],  # R4
            datadict['lsq_lat'],  # I4
            datadict['lsq_lon'],  # I4
            datadict['lsq_alt'],  # I4
            datadict['lsq_horizontal_velocity_N'],  # I4
            datadict['lsq_horizontal_velocity_E'],  # I4
            datadict['lsq_horizontal_velocity_D'],  # I4
            datadict['lsq_clock_bias'],  # R8
            datadict['lsq_clock_drift'],  # R8
            datadict['kf_lat'],  # I4
            datadict['kf_lon'],  # I4
            datadict['kf_alt'],  # I4
            datadict['kf_horizontal_velocity_N'],  # I4
            datadict['kf_horizontal_velocity_E'],  # I4
            datadict['kf_horizontal_velocity_D'],  # I4
            datadict['kf_clock_bias'],  # R8
            datadict['kf_clock_drift'],  # R8
        ) = struct.unpack('<BBHBBBBHBBiiiiIIfiiiiiiddiiiiiidd', msg_data)
        datadict['lla_valid'] = bool(pvt_status & 0b1)
        datadict['lsq_valid'] = bool(pvt_status >> 1 & 0b1)
        datadict['kf_valid'] = bool(pvt_status >> 2 & 0b1)

        yield datadict

    print("Checksum error", checksum_error_cnt, file=sys.stderr)


def velocity_track_parse(file, flow_control, check_checksum):
    lsq_coord = []
    kf_coord = []
    # calculate velocity, vertical velocity excluded
    # lsq_valid_velocity_vector = np.zeros((1, 2))
    lsq_valid_velocity_vector = [[0, 0]]
    # lsq_valid_velocity_vector[0, :] = 0
    # kf_valid_velocity_vector = np.zeros((1, 2))
    kf_valid_velocity_vector = [[0, 0]]
    # kf_valid_velocity_vector[0, :] = 0
    lsq_horizontal_velocity = []
    kf_horizontal_velocity = []
    # Clock bias and drift
    lsq_clock_bias = []
    lsq_clock_drift = []
    kf_clock_bias = []
    kf_clock_drift = []
    # calculate coordinates from velocity
    Doppler_track = np.zeros((2, 1, 2))
    # Doppler_track[:, 0, :] = 0
    # kf_or_lsq, points, E_or_N
    new_coord = np.zeros((2, 1, 2))
    n = 0
    fi = open(file[:-4] + '_Parsed raw data.txt', 'a')
    with open(file, 'rb') as f:
        data = f.read()
        # n = n+1
        for it in raw_parse(data, flow_control, check_checksum):
            # update the track data from velocity data
            if math.sqrt(it['lsq_horizontal_velocity_E'] ** 2 + it['lsq_horizontal_velocity_N'] ** 2) / 1000 > 0:
                new_coord[0, 0, 0] = it['lsq_horizontal_velocity_E'] / 1000 + Doppler_track[0, n, 0]
                new_coord[0, 0, 1] = it['lsq_horizontal_velocity_N'] / 1000 + Doppler_track[0, n, 1]
                # lsq_valid_velocity_vector = np.append(lsq_valid_velocity_vector, [[it['lsq_horizontal_velocity_E']
                # / 1000, it['lsq_horizontal_velocity_N'] / 1000]], axis=0)
            if math.sqrt(it['kf_horizontal_velocity_E'] ** 2 + it['kf_horizontal_velocity_N'] ** 2) / 100 > 0:
                new_coord[1, 0, 0] = it['kf_horizontal_velocity_E'] / 100 + Doppler_track[1, n, 0]
                new_coord[1, 0, 1] = it['kf_horizontal_velocity_N'] / 100 + Doppler_track[1, n, 1]
                # kf_valid_velocity_vector = np.append(kf_valid_velocity_vector, [[it['kf_horizontal_velocity_E'] / 100,
                # it['kf_horizontal_velocity_N'] / 100]], axis=0)

            Doppler_track = np.append(Doppler_track, new_coord, axis=1)
            n = n + 1
            if it['lsq_valid']:
                # m = m+1
                lsq_coord.extend([str(it['lsq_lon'] / 1e7), str(it['lsq_lat'] / 1e7), '0'])
                lsq_horizontal_velocity.append(math.sqrt(it['lsq_horizontal_velocity_E'] ** 2
                                                         + it['lsq_horizontal_velocity_N'] ** 2) / 1000)
                lsq_clock_bias.append(it['lsq_clock_bias'])
                lsq_clock_drift.append(it['lsq_clock_drift'])
                lsq_valid_velocity_vector.append([it['lsq_horizontal_velocity_E'] / 1000,
                                                  it['lsq_horizontal_velocity_N'] / 1000])
            else:
                lsq_horizontal_velocity.append(-0.5)
            if it['kf_valid']:
                kf_coord.extend([str(it['kf_lon'] / 1e7), str(it['kf_lat'] / 1e7), '0'])
                kf_horizontal_velocity.append(math.sqrt(it['kf_horizontal_velocity_E'] ** 2
                                                        + it['kf_horizontal_velocity_N'] ** 2) / 100)
                kf_clock_bias.append(it['kf_clock_bias'])
                kf_clock_drift.append(it['kf_clock_drift'])
                kf_valid_velocity_vector.append([it['kf_horizontal_velocity_E'] / 1000,
                                                 it['kf_horizontal_velocity_N'] / 100])
            else:
                kf_horizontal_velocity.append(-0.5)
            fi.writelines(str(it) + "\n")

            # print(it)
        # print(m)
        # print(n)
        fi.close()
        lsq_coord_data = ','.join(lsq_coord).replace(',0,', ',0 ')
        kf_coord_data = ','.join(kf_coord).replace(',0,', ',0 ')
    lsq_valid_velocity_vector = np.array(lsq_valid_velocity_vector)
    kf_valid_velocity_vector = np.array(kf_valid_velocity_vector)
    return lsq_coord_data, kf_coord_data, lsq_valid_velocity_vector, \
           kf_valid_velocity_vector, lsq_horizontal_velocity, kf_horizontal_velocity, Doppler_track
