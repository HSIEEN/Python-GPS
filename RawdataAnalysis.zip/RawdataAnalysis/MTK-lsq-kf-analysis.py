# Data : 2023/3/3 16:19
# Author: Shawn Shi
# Right Reserved By COROS
"""
MTK raw PVT parser

Usage:
    python mtk-raw-pvt-parser.py [--no-flow-control] <file>
"""
import matplotlib.pyplot as plt
import os
import sys
import numpy as np
from track_parser import track_parser
from tkinter import filedialog
import tkinter as tk
from create_KML import create_kml
from raw_parser import velocity_track_parse

if __name__ == '__main__':
    root = tk.Tk()
    root.withdraw()
    print('---------LSQ data output tool version 1.0.0-----------')
    print('-----------All rights are reserved by COROS------------')
    file = filedialog.askopenfile()
    if not file:
        sys.exit("******未选择任何文件，自动退出程序！！！******")
    path = os.path.dirname(file.name)
    lsq_coord = []
    kf_coord = []
    # calculate velocity, vertical velocity excluded
    # lsq_velocity_vector = np.zeros((1, 2))
    # kf_velocity_vector[0, :] = 0
    # lsq_horizontal_velocity = []
    # kf_horizontal_velocity = []
    # Clock bias and drift
    lsq_clock_bias = []
    lsq_clock_drift = []
    kf_clock_bias = []
    kf_clock_drift = []
    # Doppler_track[:, 0, :] = 0
    # kf_or_lsq, points, E_or_N
    new_coord = np.zeros((2, 1, 2))
    n = 0
    # m = 0
    flow_control = False
    check_checksum = True
    lsq_coord_data, kf_coord_data, lsq_velocity_vector, kf_velocity_vector, \
    lsq_horizontal_velocity, kf_horizontal_velocity, Doppler_track = \
        velocity_track_parse(file.name, flow_control, check_checksum)

    create_kml(file.name[:-4] + '_lsq_track', lsq_coord_data)
    create_kml(file.name[:-4] + '_kf_track', kf_coord_data)
    np.savetxt(file.name[:-4] + '_lsq_velocity.txt', lsq_velocity_vector)
    np.savetxt(file.name[:-4] + '_kf_velocity.txt', kf_velocity_vector)
    # plot scalar velocity information
    plt.figure()
    # plt.scatter(list(range(len(lsq_horizontal_velocity))), lsq_horizontal_velocity, marker='X',edgecolors='black')
    plt.plot(list(range(len(lsq_horizontal_velocity))), lsq_horizontal_velocity, 'r', linewidth=2,
             label='LSQ Horizontal velocity')
    plt.plot(list(range(len(kf_horizontal_velocity))), kf_horizontal_velocity, 'b', linewidth=2,
             label='KF Horizontal velocity')
    plt.legend()
    plt.grid()
    plt.xlabel('epoch/s')
    plt.ylabel('m/s')
    plt.title(' LSQ velocity vs Kf velocity')
    plt.savefig(file.name[:-4] + '_LSQ VS KF over Horizontal velocity.png')

    # plot track from velocity
    plt.figure()
    lsq_track, start_lon, start_lat = track_parser(file.name[:-4] + '_lsq_track.kml')
    kf_track, _, _ = track_parser(file.name[:-4] + '_kf_track.kml', start_lon, start_lat)
    # find the point when start running,then shift the Doppler track to align with the lsq track and the kf track
    k = 0
    J = 0
    for v in lsq_horizontal_velocity:
        if v > 0.5:
            break
        k = k + 1
    for v in kf_horizontal_velocity:
        if v > 0.5:
            break
        J = J + 1

    Doppler_track[0, :, 0] = Doppler_track[0, :, 0] + lsq_track[k, 0]
    Doppler_track[0, :, 1] = Doppler_track[0, :, 1] + lsq_track[k, 1]
    Doppler_track[1, :, 0] = Doppler_track[1, :, 0] + kf_track[J, 0]
    Doppler_track[1, :, 1] = Doppler_track[1, :, 1] + kf_track[J, 1]
    plt.plot(Doppler_track[0, :, 0], Doppler_track[0, :, 1], 'k', linewidth=2, label='LSQ Doppler track')
    plt.plot(Doppler_track[1, :, 0], Doppler_track[1, :, 1], 'm', linewidth=2, label='KF Doppler track')
    plt.plot(lsq_track[:, 0], lsq_track[:, 1], 'r', linewidth=2, label='LSQ final track')
    plt.plot(kf_track[:, 0], kf_track[:, 1], 'b', linewidth=2, label='KF final track')
    plt.legend()
    plt.xlabel('East/m')
    plt.ylabel('North/m')
    plt.title('Doppler track Vs final track')
    plt.legend()
    plt.savefig(file.name[:-4] + '_LSQ VS KF over Doppler track and final track.png')

    # plot LSQ velocity vector along the track
    plt.figure()
    plt.plot(lsq_track[:, 0], lsq_track[:, 1], 'r', linewidth=2, label='LSQ final track')
    # for n in range(len(lsq_track[:, 0])):
    #     plt.quiver(lsq_track[n, 0], lsq_track[n, 1], lsq_velocity_vector[n + 1, 0], lsq_velocity_vector[n + 1, 1]
    #                , color='k', width=0.001, headwidth=8, minshaft=2)
    plt.quiver(lsq_track[:, 0], lsq_track[:, 1], lsq_velocity_vector[1:, 0], lsq_velocity_vector[1:, 1]
               , color='k', width=0.001, headwidth=8, minshaft=2)
    plt.legend()
    plt.xlabel('East/m')
    plt.ylabel('North/m')
    plt.title('LSQ velocity and track')
    plt.legend()
    plt.savefig(file.name[:-4] + '_LSQ velocity and track.png')

    # plot KF velocity vector along the track
    plt.figure()
    plt.plot(kf_track[:, 0], kf_track[:, 1], 'b', linewidth=2, label='KF final track')
    # for n in range(len(lsq_track[:, 0])):
    #     plt.quiver(lsq_track[n, 0], lsq_track[n, 1], lsq_velocity_vector[n + 1, 0], lsq_velocity_vector[n + 1, 1]
    #                , color='k', width=0.001, headwidth=8, minshaft=2)
    if len(kf_track[:, 1]) == len(kf_velocity_vector[:, 0]):
        s = 0
    else:
        s = 1
    plt.quiver(kf_track[:, 0], kf_track[:, 1], kf_velocity_vector[s:, 0], kf_velocity_vector[s:, 1]
               , color='k', width=0.001, headwidth=8, minshaft=2)
    plt.legend()
    plt.xlabel('East/m')
    plt.ylabel('North/m')
    plt.title('KF velocity and track')
    plt.legend()
    plt.savefig(file.name[:-4] + '_KF velocity and track.png')
    # plt.plot(kf_track[:, 0], kf_track[:, 1], 'b', linewidth=2, label='KF final track')
    # plot clock bias
    # plt.figure()
    # plt.plot(list(range(len(lsq_clock_bias))), lsq_clock_bias, 'r', linewidth=2, label='LSQ clock bias')
    # plt.plot(list(range(len(kf_clock_bias))), kf_clock_bias, 'b', linewidth=2, label='KF clock bias')
    # plt.legend()
    # plt.xlabel('epoch/s')
    # plt.ylabel('m')
    # plt.title(' LSQ clock bias vs Kf clock bias')
    # # plot clock drift
    # plt.figure()
    # plt.plot(list(range(len(lsq_clock_drift))), lsq_clock_drift, 'r', linewidth=2, label='LSQ clock drift')
    # plt.plot(list(range(len(kf_clock_drift))), kf_clock_drift, 'b', linewidth=2, label='KF clock drift')
    # plt.legend()
    # plt.xlabel('epoch/s')
    # plt.ylabel('m/s')
    # plt.title(' LSQ clock bias vs Kf clock drift')
    plt.show(block=True)
