# Created by Shawn Shi at 2024/6/21

# All rights are reserved by COROS

# Have a good day always

# from math import tanh
from matplotlib import pyplot as plt
import numpy as np

if __name__ == "__main__":
    """similarity VS tanh(similarity)"""
    dtw_similarity = np.linspace(0, 40, 100)
    dtw_similarity_tanh = np.tanh(dtw_similarity / 10) * 10
    plt.figure()
    plt.plot(dtw_similarity, 10-dtw_similarity_tanh, color="black", label="similarity")
    plt.legend()
    plt.grid()
    """Convergence VS tanh(convergence)"""
    dtw_convergence = np.linspace(0, 40, 100)
    dtw_convergence_tanh = np.tanh(dtw_convergence / 5) * 10
    plt.figure()
    plt.plot(dtw_convergence, 10-dtw_convergence_tanh, color="red", label="convergence")
    plt.legend()
    plt.grid()
    # offset = 0
    offset = np.linspace(0, 50, 100)

    """similarity VS Score"""

    score = 100 - np.tanh((np.power(dtw_similarity_tanh, 1.8)) / 100) * 100
    plt.figure()
    plt.plot(dtw_similarity, score, color="green", label="similarity VS Score")
    # plt.legend()
    # plt.grid()
    """Convergence Vs Score"""
    score = 100 - np.tanh((np.power(dtw_convergence_tanh, 1.8)) / 100) * 100
    # plt.figure()
    plt.plot(dtw_convergence, score, color="blue", label="convergence VS Score")
    plt.legend()
    plt.grid()
    plt.show(block=True)
