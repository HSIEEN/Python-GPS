# Created by Shawn Shi at 2024/7/19
import time

# All rights are reserved by COROS

# Have a good day always
from openpyxl import load_workbook
from openpyxl.drawing.image import Image
import glob
import sys

if __name__ == '__main__':
    file_path = r"E:\PythonProjects\TrajectoryAnalysis\Improved-DTW-method\Block GLO\kml_file_CXY"
    img_file = r"E:\PythonProjects\TrajectoryAnalysis\Improved-DTW-method\Block GLO\kml_file_CXY\8L.png"
    img_files = glob.glob(file_path + '/*.PNG')
    if not img_files:
        sys.exit("No background image file found!!")
    file = (r"E:\PythonProjects\TrajectoryAnalysis"
            r"\Improved-DTW-method\Block GLO\kml_file_CXY\Trajectory estimation_V3.0.xlsx")
    wb = load_workbook(file)
    sheets = wb.sheetnames
    if "CXY" in sheets:
        wb.remove(wb.get_sheet_by_name("CXY"))
    ws = wb.create_sheet("CXY")
    i = 0
    for img_file in img_files:
        img = Image(img_file)
        img.width = 1000
        img.height = 1000
        # img.anchor = 'A'+str(i*55)
        ws.add_image(img, anchor='B' + str(i * 55 + 1))
        i = i+1
        # if i>2:
        #     break

    #     # time.sleep(1)
    # img_file=img_files[i]
    # img = Image(img_file)
    # img.width = 1000
    # img.height = 1000
    # img.anchor = 'A' + str(i * 55)
    # ws.add_image(img)
    # i=i+1
    # img_file = img_files[i]
    # img = Image(img_file)
    # img.width = 1000
    # img.height = 1000
    # img.anchor = 'A' + str(i * 55)
    # ws.add_image(img)


    wb.save(file)
    wb.close()
    print('')
