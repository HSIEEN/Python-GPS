import glob
import matplotlib
import os
import sys
import time
import pandas as pd
import tkinter as tk
from math import tanh
from tkinter import filedialog

import matplotlib.pyplot as plt
import numpy as np
import xlwings as xw
from openpyxl import load_workbook
from openpyxl.drawing.image import Image

from track_equalizer import track_length, equalizer
from track_parser import track_parser
from track_similarity import (track_shift_rtk2test,
                              dtw_rtk2test, dtw_test2self)

bgi_extent = {"CXY": (-235, 78, -215, 64), "YHH": (-51, 132, -240, 33), "MR": (-228, 130, -85, 310),
              "WX": (-160, 46, -62, 168), "BTZC": (-150, 130, -240, 55), "BTFC": (-180, 40, -110, 113)}
scenario = ""
line_color = ['green', 'red', 'yellow', 'blue', 'orange']
kml_group = {"1L": []}
file_path = ""
score_dataset = {"Trace name": [], "Offset(m)": [], "Convergence score": [], "Similarity score": [],
                 "Total deviation": [], "Total Score": [], "Clean name": []}
trace_images = []


def kml_classifier(target_files):
    # key_name = []
    for file in target_files:
        loop_header = file.split("\\")[-1].split('_')[0][0]
        right_left = file.split(')')[1][1]
        key_str = loop_header + right_left
        if key_str not in kml_group:
            kml_group[key_str] = []
        kml_group[key_str].append(file)


def format_excel(excel_file):
    wb = xw.Book(excel_file)
    ws = wb.sheets['Scores']
    ws.range('A1:J1').color = (255, 217, 100)
    ws.range('A1').column_width = 85
    ws.range('B1').column_width = 16
    ws.range('C1:F1').column_width = 25
    ws.range('B1:B100').api.Font.Bold = True
    ws.range('C1:C100').api.Font.Bold = True
    ws.range('E1:E100').api.Font.Bold = True
    ws.range('D1:D100').api.Font.Bold = True
    ws.range('F1:F100').api.Font.Bold = True
    ws.range('B1').api.Font.ColorIndex = 3
    ws.range('C1').api.Font.ColorIndex = 3
    ws.range('D1').api.Font.ColorIndex = 3
    ws.range('F1:F100').api.Font.ColorIndex = 3
    ws.range('A1:J100').api.HorizontalAlignment = -4108
    ws.range('A2:A100').api.HorizontalAlignment = -4131
    return wb


def remove_duplicated_timestamp(kml_str):
    clean_name = kml_str.split("\\")[-1].split(".")[0]
    suffix_name = clean_name.split(")")[-1]
    if len(suffix_name) > 25:
        return clean_name.split(" ")[0][:-11]
    else:
        return clean_name


def graph_generator(rtk_trace, test_traces):
    print("*************Now begin generating pictures......................\n")
    img = ""
    img_files = glob.glob(file_path + '/*.JPG')
    if not img_files:
        sys.exit("No background image file found!!")
    for img_file in img_files:
        if "BGI" in img_file:
            img = plt.imread(img_file)
            break
    for key in kml_group:
        legend_items = []
        i = 0
        plt.figure()
        plt.imshow(img, extent=bgi_extent[scenario])
        plt.plot(rtk_trace[:, 0], rtk_trace[:, 1], line_color[i], linewidth=1.5)
        legend_items.append("RTK_trace")
        i = i + 1
        for kml_file in kml_group[key]:
            plt.plot(test_traces[kml_file][:, 0],
                     test_traces[kml_file][:, 1], line_color[i], linewidth=0.8)
            # tmp = remove_duplicated_timestamp(kml_file)
            if "log_system" in kml_file:
                legend_items.append(remove_duplicated_timestamp(kml_file).replace("log_system_", '')[:-22])
            else:
                legend_items.append(remove_duplicated_timestamp(kml_file)[:-20])
            i = i + 1
        plt.legend(legend_items, fontsize=5)
        # plt.xlabel('East (m)')
        plt.xticks([])
        plt.yticks([])
        # plt.ylabel('North (m)')
        plt.title("Round_" + key, fontsize=8)
        plt.savefig(file_path + "\\" + key, dpi=1200, bbox_inches='tight')
        fig_file = file_path + "\\" + key + '.PNG'
        print(f"***Saving figure {fig_file}....\n")
        # plt.pause(0.5)
        trace_images.append(fig_file)


def copy_graphs_to_sheet(file):
    width = 1000
    height = 1000
    wb = load_workbook(file)
    sheets = wb.sheetnames
    if scenario in sheets:
        wb.remove(wb.get_sheet_by_name(scenario))
    ws = wb.create_sheet(scenario)
    li = 0
    ri = 0
    for pic in trace_images:
        img = Image(pic)
        img.width = width
        img.height = height
        if 'L' in pic.split('\\')[-1]:
            img.anchor = 'A' + str(li * 53 + 1)
            # ws.pictures.add(pic, left=100, top=100 + li * height, width=width, height=height)
            ws.add_image(img)
            li = li + 1
        elif 'R' in pic.split('\\')[-1]:
            img.anchor = 'Q' + str(ri * 53 + 1)
            # ws.pictures.add(pic, left=100 + width, top=100 + ri * height, width=width, height=height)
            ws.add_image(img)
            ri = ri + 1
    wb.save(file)


def scenario_judgement(rtk_kml):
    global scenario
    if "CXY" in rtk_kml:
        scenario = "CXY"
    elif "YHH" in rtk_kml:
        scenario = "YHH"
    elif "WX" in rtk_kml:
        scenario = "WX"
    elif "MR" in rtk_kml:
        scenario = "MR"
    elif "BTZC" in rtk_kml:
        scenario = "BTZC"
    elif "BTFC" in rtk_kml:
        scenario = "BTFC"
    if not rtk_kml:
        print('No RTK trajectory kml_file found!!')
        exit()


if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    matplotlib.use("tkagg")
    version_str = "V3.1"
    print("************Trace estimation for COROS " + version_str + "*************")
    print("*************ALL RIGHTS ARE RESERVED BY COROS*****************")
    print("Update log:\n1. Use sigmoid function to get similarity and convergence")
    print("2. Use sigmoid function to get scores")
    print("3. Change similarity scale factor from 8 to 12")
    print("4. Add functions to plot graphs with background images")
    print("5. Fix some legend display issues in charts")
    print("6. Reduce the line width of test trace in charts to 0.8 and increase that of rtk trace to 1.5")
    print("7. Delete the redundant timestamp when displaying the legends ")
    print("8. Make the figure margin fit the size of graph ")
    print("9. Change a bgi in MR scenario ")
    print("10. Add function to paste pictures ")
    print("11. Auto-sort the scoring by device id instead of kml name ")
    print("12. Make legend name shorter to avoid blocking trace show ")
    print('***************请选择要分析的文件目录*****************************')

    file_path = filedialog.askdirectory()
    if file_path == '':
        print("No directory was chosen, exit.")
        sys.exit()
    print(f"******The selected path is {file_path}******\n")
    kml_files = glob.glob(file_path + '/*.kml')
    standard_kml = next((kml_file for kml_file in kml_files if 'RTK' in kml_file), None)
    scenario_judgement(standard_kml)
    kml_files.remove(standard_kml)
    kml_classifier(kml_files)
    test_tracks = {}
    test_equalized_tracks = {}
    # test_delta_len = {}

    rtk_track, start_lon, start_lat = track_parser(standard_kml)
    rtk_equalized_track, rtk_delta_len = equalizer(rtk_track, True)
    rtk_length = track_length(rtk_equalized_track)

    # get trajectory data
    for kml_file in kml_files:
        try:
            test_tracks[kml_file], _, _ = track_parser(kml_file, start_lon, start_lat)
            test_equalized_tracks[kml_file], _ = equalizer(test_tracks[kml_file], False)
        except Exception as e:
            print(e)
            print("Some kml files seems to go wrong, please check them!!")
            time.sleep(2)
            sys.exit("!")
    # row = 1
    # """Read an image as the background"""
    # img_files = glob.glob(file_path + '/*.JPG')
    # if not img_files:
    #     sys.exit("No background image file found!!")
    # for img_file in img_files:
    #     if "BGI" in img_file:
    #         img = plt.imread(img_file)
    #         break
    for kml_file in kml_files:
        n = len(kml_files)
        file_str = kml_file.split("\\")
        filename = file_str[-1]
        filename = filename[:-4]
        print(f"*********** The kml file {filename} is in process..........\n")
        score_dataset["Trace name"].append(filename)
        score_dataset["Clean name"].append(filename[4:])
        """offset estimation"""
        shift_vector = track_shift_rtk2test(rtk_equalized_track, test_equalized_tracks[kml_file])
        """Convergence estimation"""
        dtw_convergence = dtw_test2self(test_equalized_tracks[kml_file])
        """Shifted trace estimation"""
        test_shifted_track = test_equalized_tracks[kml_file] - shift_vector
        """DTW distance estimation---total deviation estimation"""
        dtw_deviation = dtw_rtk2test(rtk_equalized_track, test_equalized_tracks[kml_file],
                                     similarity_or_deviation="deviation")
        """Similarity estimation"""
        dtw_similarity = dtw_rtk2test(rtk_equalized_track, test_equalized_tracks[kml_file],
                                      similarity_or_deviation="similarity")
        """Add weight to similarity and convergence"""
        dtw_similarity = tanh(dtw_similarity / 12) * 10
        dtw_convergence = tanh(dtw_convergence / 8) * 10
        """Trace length estimation"""
        len_track = track_length(test_equalized_tracks[kml_file])
        loop_number = 3
        offset = np.linalg.norm(shift_vector)
        score_dataset["Offset(m)"].append(round(offset, 2))
        score_dataset["Convergence score"].append(round(10 - dtw_convergence, 2))
        score_dataset["Similarity score"].append(round(10 - dtw_similarity, 2))
        score_dataset["Total deviation"].append(round(dtw_deviation, 2))
        """Calculate scores"""
        score = 100 - tanh((dtw_convergence ** 2 + dtw_similarity ** 2 + offset) / 100) * 100
        score_dataset["Total Score"].append(round(score, 2))
        #
        # plt.figure()
        # plt.imshow(img, extent=(-228, 130, -85, 310))
        # plt.plot(rtk_equalized_track[:, 0], rtk_equalized_track[:, 1], 'green', linewidth=1.2)
        # # plt.plot(test_equalized_tracks[kml_file][:, 0], test_equalized_tracks[kml_file][:, 1], 'g', linewidth=1,
        # # label="test_track" + "\n" + "total Score: " + str(round(score, 2)) + "\n" + "Convergence score: " +
        # # str(round(10 - dtw_convergence, 2)) + "\n" + "Similarity score: " + str(
        # # round(10 - dtw_similarity, 2)) + "\n" + "offset: " + str(round(offset, 2)) + "m")
        # plt.plot(test_equalized_tracks[kml_file][:, 0], test_equalized_tracks[kml_file][:, 1],
        #          'red', linewidth=1.2)
        # # plt.plot(test_shifted_track[:, 0], test_shifted_track[:, 1], 'b', linewidth=2, label="shifted")
        # SMALL_SIZE = 8
        # MEDIUM_SIZE = 10
        # BIGGER_SIZE = 12
        # plt.xticks([])
        # plt.yticks([])
        # # plt.xlabel('East (m)', fontsize=5)
        # # plt.ylabel('North (m)', fontsize=5)
        # plt.title("test", fontsize=8)
        # plt.savefig(file_path + '\\' + filename + '.png', dpi=1000, bbox_inches='tight')
        # print(" ")
    df = pd.DataFrame(score_dataset)
    df = df.sort_values(by='Clean name')
    excel_file = file_path + '\\' + 'Trajectory estimation_' + version_str + '.xlsx'
    if os.path.exists(excel_file):
        os.remove(excel_file)
    df.to_excel(excel_writer=excel_file, sheet_name="Scores", index=False,
                columns=list(col for col in list(score_dataset.keys()) if col != "Clean name"))
    wb = format_excel(excel_file)
    wb.save()
    wb.close()
    xw.App().quit()
    # plt.show(block=True)
    graph_generator(rtk_equalized_track, test_equalized_tracks)

    copy_graphs_to_sheet(excel_file)

    print("*****************************Process ends normally*************************")
