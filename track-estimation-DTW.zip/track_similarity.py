# Created by Shawn Shi at 2024/6/7

# All rights are reserved by COROS

# Have a good day always

from track_equalizer import euclidean, track_spliter, equalizer, track_length
import numpy as np
import matplotlib.pyplot as plt
import numba
# from fastdtw import fastdtw

#
"""
Euclidean distance point by point
"""


@numba.jit(nopython=True, fastmath=True)
def track_euclidean_track2track(rtk_track, test_track, after_shift=False):
    total_deviation = 0
    max_deviation = 0
    deviation_arr = np.zeros((1000, 1))
    if after_shift:
        shift_vector = track_shift_track2track(rtk_track, test_track)
        test_track = test_track - shift_vector
    for i in range(1000):
        delta = euclidean(rtk_track[i, :], test_track[i, :])
        deviation_arr[i] = delta
        total_deviation = delta + total_deviation
        if delta > max_deviation:
            max_deviation = delta
    return total_deviation / len(rtk_track), max_deviation, deviation_arr


def track_euclidean_rtk2test(coord_rtk, coord_test):
    test_track_segments = track_spliter(coord_test)
    total_average_deviation = 0
    max_deviation = 0
    deviation_arr = np.zeros((3000, 1))
    for i in range(3):
        delta, temp_max, deviation_arr[i * 1000:i * 1000 + 1000] = \
            track_euclidean_track2track(coord_rtk, test_track_segments[i, :, :])
        total_average_deviation = total_average_deviation + delta
        if temp_max > max_deviation:
            max_deviation = temp_max
    return total_average_deviation / 3, max_deviation, deviation_arr


@numba.jit(nopython=True, fastmath=True)
def track_shift_track2track(rtk_track, test_track):
    # rtk_avg = np.average(rtk_track, axis=0)
    rtk_avg = np.array([0, 0], dtype=np.float64)
    for i in range(len(rtk_track)):
        rtk_avg = rtk_avg + rtk_track[i, :]
    rtk_avg = rtk_avg / len(rtk_track)
    # test_avg = np.average(test_track, axis=0)
    test_avg = np.array([0, 0], dtype=np.float64)
    for i in range(len(test_track)):
        test_avg = test_avg + test_track[i, :]
    test_avg = test_avg / len(rtk_track)
    shift_vector = test_avg - rtk_avg
    return shift_vector


def track_shift_rtk2test(coord_rtk, coord_test):
    test_track_segments = track_spliter(coord_test)
    total_average_shift = np.array([0, 0])
    for i in range(3):
        shift = track_shift_track2track(coord_rtk, test_track_segments[i, :, :])
        total_average_shift = total_average_shift + shift
    return total_average_shift / 3


def track_euclidean_test2self(coord_test):
    test_track_segments = track_spliter(coord_test)
    sim_1_to_0, _, _ = track_euclidean_track2track(test_track_segments[0, :, :], test_track_segments[1, :, :])
    sim_1_to_2, _, _ = track_euclidean_track2track(test_track_segments[1, :, :], test_track_segments[2, :, :])
    sim_0_to_2, _, _ = track_euclidean_track2track(test_track_segments[0, :, :], test_track_segments[2, :, :])

    total_average_deviation = (sim_0_to_2 + sim_1_to_2 + sim_1_to_0) / 3
    return total_average_deviation


def correspondence_euclidean_plot(rtk_track, test_track):
    plt.figure()
    plt.plot(rtk_track[:, 0], rtk_track[:, 1], 'g', linewidth=2, label='RTK_track')
    plt.plot(test_track[:, 0], test_track[:, 1], 'r', linewidth=2, label='test_track')
    for n in range(len(rtk_track), 10):
        plt.plot([rtk_track[n, 0], test_track[n, 0]],
                 [rtk_track[n, 1], test_track[n, 1]])
    # plt.grid(visible=True)
    plt.show(block=True)


"""
Hausdorff distance 
"""


@numba.jit(nopython=True, fastmath=True)
def hausdorff_distance(rtk_track, test_track, after_shift=False):
    if after_shift:
        shift_vector = track_shift_track2track(rtk_track, test_track)
        test_track = test_track - shift_vector
    rtk_track_points_num = rtk_track.shape[0]
    test_track_points_num = test_track.shape[0]
    distance_max = 0.
    rtk2test_pairs = np.zeros(rtk_track_points_num)
    index = 0
    for i in range(rtk_track_points_num):
        distance_min = np.inf
        for j in range(test_track_points_num):
            d = euclidean(rtk_track[i, :], test_track[j, :])
            if d < distance_min:
                distance_min = d
                index = j
            # if distance_min < distance_max:
            # break
        rtk2test_pairs[i] = index
        if distance_max < distance_min < np.inf:
            distance_max = distance_min
    # plot points pairs
    test2rtk_pairs = np.zeros(test_track_points_num)
    index = 0
    for j in range(test_track_points_num):
        distance_min = np.inf
        for i in range(rtk_track_points_num):
            d = euclidean(rtk_track[i, :], test_track[j, :])
            if d < distance_min:
                distance_min = d
                index = i
            # if distance_min < distance_max:
            # break
        test2rtk_pairs[j] = index
        if distance_max < distance_min < np.inf:
            distance_max = distance_min

    return distance_max, rtk2test_pairs, test2rtk_pairs


"""
DTW distance 
"""


# @numba.jit(nopython=True, fastmath=True)
def dtw_rtk2test(rtk_track, test_track, similarity_or_deviation="similarity"):
    test_track_segments = track_spliter(test_track, False)
    total_cost = 0
    if similarity_or_deviation == "similarity":
        for i in range(3):
            """Calculate correspondence relationship after shift"""
            _, path, cost_matrix = dtw_track2track(rtk_track, test_track_segments[i, :, :], after_shift=True)
            N, M = cost_matrix.shape
            cost = cost_matrix[N - 1, M - 1] / len(path)
            total_cost = total_cost + cost
        return total_cost / 3
    elif similarity_or_deviation == "deviation":
        total_len = 0
        for i in range(3):
            """Calculate correspondence relationship after shift"""
            _, path, cost_matrix = dtw_track2track(rtk_track, test_track_segments[i, :, :], after_shift=True)
            total_len = total_len + len(path)
            # N, M = cost_matrix.shape
            # total_cost = 0
            for x, y in path:
                total_cost = total_cost + euclidean(rtk_track[x, :], test_track_segments[i, y, :])
        return total_cost / total_len
    else:
        for i in range(3):
            """Calculate correspondence relationship after shift"""
            _, path, cost_matrix = dtw_track2track(rtk_track, test_track_segments[i, :, :], after_shift=False)
            N, M = cost_matrix.shape
            cost = cost_matrix[N - 1, M - 1] / len(path)
            total_cost = total_cost + cost
        return total_cost / 3


# @numba.jit(nopython=True, fastmath=True)
def dtw_test2self(test_track):
    test_track_segments = track_spliter(test_track, False)
    _, path10, cost_mat10 = dtw_track2track(test_track_segments[0, :, :], test_track_segments[1, :, :])
    _, path12, cost_mat12 = dtw_track2track(test_track_segments[1, :, :], test_track_segments[2, :, :])
    _, path20, cost_mat20 = dtw_track2track(test_track_segments[0, :, :], test_track_segments[2, :, :])
    N12, M12 = cost_mat12.shape
    N10, M10 = cost_mat10.shape
    N20, M20 = cost_mat20.shape
    cost12 = cost_mat12[N12 - 1, M12 - 1] / len(path12)
    cost10 = cost_mat10[N10 - 1, M10 - 1] / len(path10)
    cost20 = cost_mat12[N20 - 1, M20 - 1] / len(path20)

    total_cost = (cost12 + cost20 + cost10) / 3

    return total_cost


@numba.jit(nopython=True, fastmath=True)
def dtw_track2track(rtk_track, test_track, after_shift=False):
    """
    Find minimum-cost path through matrix `dist_mat` using dynamic programming.

    The cost of a path is defined as the sum of the matrix entries on that
    path. See the following for details of the algorithm:

    - http://en.wikipedia.org/wiki/Dynamic_time_warping
    - https://www.ee.columbia.edu/~dpwe/resources/matlab/dtw/dp.m

    The notation in the first reference was followed, while Dan Ellis's code
    (second reference) was used to check for correctness. Returns a list of
    path indices and the cost matrix.
    """
    rtk_epoch = len(rtk_track)
    test_epoch = len(test_track)
    if after_shift:
        shift_vector = track_shift_track2track(rtk_track, test_track)
        test_track = test_track - shift_vector
    dist_mat = np.zeros((rtk_epoch, test_epoch))

    """test code here, random offset should get higher weight and the synchronized offset should get lower weight"""
    for i in range(rtk_epoch):
        for j in range(test_epoch):
            dist_mat[i, j] = euclidean(rtk_track[i, :], test_track[j, :])

    # Initialize the cost matrix
    cost_mat = np.zeros((rtk_epoch + 1, test_epoch + 1))
    for i in range(1, rtk_epoch + 1):
        cost_mat[i, 0] = np.inf
    for i in range(1, test_epoch + 1):
        cost_mat[0, i] = np.inf

    # Fill the cost matrix while keeping trackback information
    traceback_mat = np.zeros((rtk_epoch, test_epoch))
    for i in range(rtk_epoch):
        for j in range(test_epoch):
            penalty = [
                cost_mat[i, j],  # match (0)
                cost_mat[i, j + 1],  # insertion (1)
                cost_mat[i + 1, j]]  # deletion (2)
            # i_penalty = np.argmin(penalty)
            i_penalty = 0
            if cost_mat[i, j] <= cost_mat[i, j + 1] and cost_mat[i, j] <= cost_mat[i + 1, j]:
                i_penalty = 0
            elif cost_mat[i, j + 1] <= cost_mat[i, j] and cost_mat[i, j + 1] <= cost_mat[i + 1, j]:
                i_penalty = 1
            elif cost_mat[i + 1, j] <= cost_mat[i, j + 1] and cost_mat[i + 1, j] <= cost_mat[i, j + 1]:
                i_penalty = 2
            cost_mat[i + 1, j + 1] = dist_mat[i, j] + penalty[i_penalty]
            traceback_mat[i, j] = i_penalty

    # traceback from bottom right
    i = rtk_epoch - 1
    j = test_epoch - 1
    path = [(i, j)]
    while i > 0 or j > 0:
        tb_type = traceback_mat[i, j]
        if tb_type == 0:
            # Match
            i = i - 1
            j = j - 1
        elif tb_type == 1:
            # Insertion
            i = i - 1
        elif tb_type == 2:
            # Deletion
            j = j - 1
        path.append((i, j))

    # Strip infinity edges from cost_mat before returning
    cost_mat = cost_mat[1:, 1:]
    return (dist_mat, path[::-1], cost_mat)


if __name__ == "__main__":
    from track_parser import track_parser

    rtk_kml = r"CXY\CXY_RTK.kml"
    test_kml = r"CXY\B19_1#_708ba9_G3B(L1+L5)_L_2023-02-09 15_55_11.kml"

    file_str = test_kml.split("\\")
    filename = file_str[-1]
    filename = filename[:-4]

    rtk_track, rtk_lon, rtk_lat = track_parser(rtk_kml)
    rtk_equalized_track = equalizer(rtk_track, True)

    rtk_length = track_length(rtk_track)
    test_track, test_lon, test_lat = track_parser(test_kml, rtk_lon, rtk_lat)

    test_equalized_track = equalizer(test_track, False)

    for segment_num in range(3):
        # segment_num = 0

        print(f"Loop {str(segment_num + 1)}\n")
        index = slice(segment_num * 1000, segment_num * 1000 + 1000)
        shift = track_shift_track2track(rtk_equalized_track, test_equalized_track[index, :])
        print(f"offset distance {round(np.linalg.norm(shift), 2)}m\n")
        """Point by point Euclidean distance"""
        dist_pbp, _, _ = track_euclidean_track2track(rtk_equalized_track, test_equalized_track[index, :])
        dist_pbp_shifted, _, _ = track_euclidean_track2track(rtk_equalized_track, test_equalized_track[index, :],
                                                             after_shift=True)
        print(f"Point by point distance: {dist_pbp}m")
        print(f"Point by point after shift: {dist_pbp_shifted}m")
        plt.figure()
        plt.title("Point by point")
        plt.plot(rtk_equalized_track[:, 0], rtk_equalized_track[:, 1], 'g', linewidth=2, label='RTK_track')
        plt.plot(test_equalized_track[index, 0], test_equalized_track[index, 1], 'b', linewidth=2,
                 label=f'Test_track Euclidean distance: {round(dist_pbp / 1000, 2)}m')
        for n in range(0, len(rtk_equalized_track), 5):
            plt.plot([rtk_equalized_track[n, 0], test_equalized_track[n + segment_num * 1000, 0]],
                     [rtk_equalized_track[n, 1], test_equalized_track[n + segment_num * 1000, 1]], color="r")
        # plt.grid(visible=True)
        plt.axis("off")
        plt.legend()
        plt.savefig(r"CXY\Fig" + "\\" + filename + str(segment_num) + "PBP.png")

        """Hausdorff estimation"""
        plt.figure()
        plt.title("Hausdorff")
        hausdorff_dist, rtk2test, test2rtk = hausdorff_distance(rtk_equalized_track, test_equalized_track[index, :])
        hausdorff_dist_shifted, _, _ = hausdorff_distance(rtk_equalized_track, test_equalized_track[index, :],
                                                          after_shift=True)
        plt.plot(rtk_equalized_track[:, 0], rtk_equalized_track[:, 1], 'g', linewidth=2, label='RTK_track')
        plt.plot(test_equalized_track[index, 0], test_equalized_track[index, 1], 'b', linewidth=2,
                 label=f"Test_track: Hausdorff distance {round(hausdorff_dist, 2)}m")
        plt.legend()

        print(f"Hausdorff distance: {hausdorff_dist}m")
        print(f"Hausdorff distance after shift: {hausdorff_dist_shifted}m")
        # field vector plot

        # for n in range(0, len(rtk_equalized_track), 10):
        # plt.plot([rtk_equalized_track[n, 0], test_equalized_track[int(rtk2test[n]), 0]],
        # [rtk_equalized_track[n, 1], test_equalized_track[int(rtk2test[n]), 1]], color="g")

        for n in range(0, 1000, 5):
            plt.plot([rtk_equalized_track[int(test2rtk[n]), 0], test_equalized_track[n + segment_num * 1000, 0]],
                     [rtk_equalized_track[int(test2rtk[n]), 1], test_equalized_track[n + segment_num * 1000, 1]],
                     color="r")
        # plt.quiver(test_equalized_track[:1000, 0], test_equalized_track[: 1000, 1],
        # rtk_equalized_track[:, 0]-test_equalized_track[:1000, 0],
        # rtk_equalized_track[:, 1]-test_equalized_track[: 1000, 1], color="blue", scale=100)
        plt.savefig(r".\CXY\Fig" + "\\" + filename + str(segment_num) + "HSD.png")

        """DTW estimation"""
        # dist_mat, path, cost_mat = dtw_track2track(rtk_equalized_track, test_equalized_track[:1000, :])
        dist_mat, path, cost_mat = dtw_track2track(rtk_equalized_track, test_equalized_track[index, :],
                                                   after_shift=False)
        N, M = dist_mat.shape
        # Alignment_cost = cost_mat[N - 1, M - 1]
        # total_cost = 0
        # for x, y in path:
        # total_cost = total_cost + euclidean(rtk_equalized_track[x, :], test_equalized_track[y, :])

        _, path_shifted, cost_mat_shifted = dtw_track2track(rtk_equalized_track, test_equalized_track[index, :],
                                                            after_shift=True)
        # Alignment_cost_shifted = cost_mat_shifted[N - 1, M - 1]
        # total_cost_shifted = 0
        # for x, y in path_shifted:
        #     total_cost_shifted = total_cost + euclidean(rtk_equalized_track[x, :], test_equalized_track[y, :])
        # print("Alignment cost: {:.4f}".format(cost_mat[N - 1, M - 1]))
        print("Normalized alignment cost: {:.4f}".format(cost_mat[N - 1, M - 1] / (N + M)))
        print("Normalized alignment  cost after shift: {:.4f}".format(cost_mat_shifted[N - 1, M - 1] / (N + M)))
        # fastdtw_dist, fastpath = fastdtw(rtk_equalized_track, test_equalized_track[index, :], dist=euclidean)
        # print("Distance from fastdtw: ", fastdtw_dist)

        plt.figure(figsize=(6, 4))
        plt.subplot(121)
        plt.title("Distance matrix")
        plt.imshow(dist_mat, cmap=plt.cm.binary, interpolation="nearest", origin="lower")
        plt.subplot(122)
        plt.title("Cost matrix")
        plt.imshow(cost_mat, cmap=plt.cm.binary, interpolation="nearest", origin="lower")
        x_path, y_path = zip(*path)
        plt.plot(y_path, x_path, color="r")

        plt.figure()
        plt.title("Dynamic time warping")
        plt.plot(rtk_equalized_track[:, 0], rtk_equalized_track[:, 1], 'g', linewidth=2, label='RTK_track')
        plt.plot(test_equalized_track[index, 0], test_equalized_track[index, 1], 'b', linewidth=2,
                 label=f"Test_track: normalized cost {round(cost_mat[N - 1, M - 1] / (N + M), 2)}")
        index_plot = slice(0, len(path), 5)
        path_plot = path[index_plot]
        path_shifted_plot = path_shifted[index_plot]
        for x_i, y_j in path_plot:
            plt.plot([rtk_equalized_track[x_i, 0], test_equalized_track[segment_num * 1000 + y_j, 0]],
                     [rtk_equalized_track[x_i, 1], test_equalized_track[segment_num * 1000 + y_j, 1]], color="r")
        # for x_i, y_j in path_shifted_plot:
            # plt.plot([rtk_equalized_track[x_i, 0], test_equalized_track[segment_num * 1000 + y_j, 0]],
                     # [rtk_equalized_track[x_i, 1], test_equalized_track[segment_num * 1000 + y_j, 1]], color="black")
        plt.axis("off")
        plt.legend()
        plt.savefig(r".\CXY\Fig" + "\\" + filename + str(segment_num) + "DTW.png")
        plt.show(block=True)
