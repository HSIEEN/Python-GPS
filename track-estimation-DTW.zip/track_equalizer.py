# Created by Shawn Shi at 2024/6/6
import sys
import numba

# All rights are reserved by COROS

# Have a good day always
import numpy as np
from math import sqrt
import matplotlib.pyplot as plt


@numba.jit(nopython=True, fastmath=True)
def track_length(coord):
    length = 0
    for i in range(1, len(coord)):
        delta = euclidean(coord[i, :], coord[i - 1, :])
        length = length + delta
    return length


@numba.jit(nopython=True, fastmath=True)
def euclidean(array_x, array_y):
    n = array_x.shape[0]
    ret = 0.
    for i in range(n):
        ret += (array_x[i] - array_y[i]) ** 2
    return sqrt(ret)
    # return ret


@numba.jit(nopython=True, fastmath=True)
def start_point_finder(coord_arr):
    dot_num = coord_arr.shape[0]
    for i in range(dot_num):
        j = 0
        for j in range(i, i + 5):
            delta = euclidean(coord_arr[j, :], coord_arr[j + 1, :])
            if delta < 1.5:
                break
        if j == i + 4:
            return i


@numba.jit(nopython=True, fastmath=True)
def end_point_finder(coord_arr):
    dot_num = coord_arr.shape[0]
    for i in range(dot_num):
        j = 0
        for j in range(i, i + 5):
            delta = euclidean(coord_arr[dot_num - j - 1, :], coord_arr[dot_num - j - 2, :])
            if delta < 1.5:
                break
        if j == i + 4:
            return dot_num - i


@numba.jit(nopython=True, fastmath=True)
def equalizer(coord_arr, is_rtk=False):
    new_dot_num = 3000
    if is_rtk:
        new_dot_num = 1000
    else:  # remove non-effective start point and end points
        start_x = start_point_finder(coord_arr)
        end_x = end_point_finder(coord_arr)
        coord_arr = coord_arr[start_x:end_x, :]
    length = track_length(coord_arr)
    delta_len = length / (new_dot_num - 1)  # new length segments size
    dot_num = coord_arr.shape[0]
    p = 0  # current index of new coordinates
    cur_len_old = 0
    cur_len_new = 0
    new_coord = np.zeros((new_dot_num, 2))
    new_coord[p, :] = coord_arr[0, :]
    for i in range(1, dot_num):
        cur_segment_old = euclidean(coord_arr[i, :], coord_arr[i - 1, :])
        cur_len_old = cur_len_old + cur_segment_old
        while cur_len_old > cur_len_new + delta_len:
            p = p + 1
            if p > 2990:
                pass
            cur_len_new = cur_len_new + delta_len
            rest_len = cur_len_old - cur_len_new
            multi_factor = (cur_segment_old - rest_len) / cur_segment_old
            new_coord[p, 0] = (coord_arr[i, 0] - coord_arr[i - 1, 0]) * multi_factor + coord_arr[i - 1, 0]
            new_coord[p, 1] = (coord_arr[i, 1] - coord_arr[i - 1, 1]) * multi_factor + coord_arr[i - 1, 1]
    return new_coord
    # print("test")


def track_spliter(coord_arr, is_rtk=False):
    if is_rtk:
        sys.exit("RTK track has no need to do segmentation")
    # location=0 YHH, 1 for CXY, 2 for Mindray, 3 for wenxin park, 4 for baoan stadium
    track_segments = np.zeros((3, 1000, 2))
    track_segments[0, :, :] = coord_arr[:1000, :]
    track_segments[1, :, :] = coord_arr[1000:2000, :]
    track_segments[2, :, :] = coord_arr[2000:3000, :]
    return track_segments


if __name__ == "__main__":
    from track_parser import track_parser

    rtk_kml = r"YHH\YHH_RTK.kml"
    test_kml = r"YHH\1TH_log_system_4778_2#_e7f551_G3B(L1)_R_2024-05-07_06_13_38_2024-05-07 06_13_38.kml"
    plt.figure()
    rtk_track, rtk_lon, rtk_lat = track_parser(rtk_kml)
    rtk_equalized_track = equalizer(rtk_track, True)

    rtk_length = track_length(rtk_track)
    test_track, test_lon, test_lat = track_parser(test_kml, rtk_lon, rtk_lat)
    # plt.plot(rtk_track[:, 0], rtk_track[:, 1], 'g', linewidth=2, label='RTK_Track')
    # plt.plot(test_track[:, 0], test_track[:, 1], 'b', linewidth=2, label='test_Track')
    # plt.scatter(rtk_track[:, 0], rtk_track[:, 1], c='b', marker="o", linewidth=2, label='RTK_Track')
    plt.scatter(rtk_equalized_track[:, 0], rtk_equalized_track[:, 1], c='c', marker="o")

    # start = start_point_finder(test_track)
    # end = end_point_finder(test_track)
    # test_track = test_track[start:end, :]
    test_equalized_track = equalizer(test_track, False)

    # plt.scatter(test_track[:, 0], test_track[:, 1], c='b', marker="o", linewidth=2, label='RTK_Track')
    plt.scatter(test_equalized_track[:1000, 0], test_equalized_track[:1000, 1], c='r', marker="*")
    plt.scatter(test_equalized_track[1000:2000, 0], test_equalized_track[1000:2000, 1], c='b', marker="*")
    plt.scatter(test_equalized_track[2000:3000, 0], test_equalized_track[2000:3000, 1], c='g', marker="*")

    # plt.figure()
    # plt.plot(test_track[:, 0], test_track[:, 1], 'r', linewidth=2, label='test_Track')
    plt.grid(visible=True)
    plt.show(block=True)
    print("test")
