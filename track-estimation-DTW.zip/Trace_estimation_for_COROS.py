import numpy as np
import matplotlib.pyplot as plt
import matplotlib
from track_parser import track_parser
from track_equalizer import track_length, equalizer
from track_similarity import (track_shift_rtk2test,
                              hausdorff_distance, dtw_rtk2test, dtw_test2self)
import glob
import xlwings as xw
import tkinter as tk
from tkinter import filedialog
import os
from math import ceil

root = tk.Tk()
root.withdraw()

matplotlib.use("tkagg")
print('***************请选择要分析的文件目录****************')

file_path = filedialog.askdirectory()
if file_path == '':
    print("No directory was chosen, exit.")
    exit()
files = glob.glob(file_path + '/*.kml') + glob.glob(file_path + '/*.gpx')
standard_kml = next((file for file in files if 'RTK' in file), None)
if not standard_kml:
    print('No RTK trajectory file found!!')
    exit()
files.remove(standard_kml)
test_tracks = {}
test_equalized_tracks = {}

rtk_track, start_lon, start_lat = track_parser(standard_kml)
rtk_equalized_track = equalizer(rtk_track, True)
rtk_length = track_length(rtk_equalized_track)

# get trajectory data
for file in files:
    test_tracks[file], _, _ = track_parser(file, start_lon, start_lat)
    test_equalized_tracks[file] = equalizer(test_tracks[file], False)

wb = xw.Book()
if os.path.exists(file_path + '\\' + 'Trajectory estimation.xlsx'):
    os.remove(file_path + '\\' + 'Trajectory estimation.xlsx')
wb.save(file_path + '\\' + 'Trajectory estimation.xlsx')
wb.sheets['Sheet1'].name = 'data'
ws = wb.sheets['data']
ws.range('A1').value = 'Trace name'
ws.range('B1').value = 'Trace length(m)'
ws.range('C1').value = 'Offset(m)'
ws.range('D1').value = 'Convergence score'
ws.range('E1').value = 'Similarity score'
ws.range('F1').value = 'Total deviation(m)'
ws.range('G1').value = 'Total score'
# ws.range('H1').value = 'Shifted Hausdorff distance(m)'
# ws.range('I1').value = 'Shifted DTW distance'
# ws.range('J1').value = 'Self DTW distance'
# ws.range('H1').value = '偏移大于8m占比'
ws.range('A1:J1').color = (255, 217, 100)
ws.range('A1').column_width = 30
ws.range('B1:C1').column_width = 16
ws.range('D1:J1').column_width = 25
ws.range('B1:B100').api.Font.Bold = True
ws.range('C1:C100').api.Font.Bold = True
ws.range('E1:E100').api.Font.Bold = True
ws.range('D1:D100').api.Font.Bold = True
ws.range('F1:F100').api.Font.Bold = True
ws.range('G1:G100').api.Font.Bold = True
ws.range('H1:H100').api.Font.Bold = True
ws.range('D1').api.Font.ColorIndex = 3
# ws.range('D1:D100').api.Font.ColorIndex = 3
ws.range('C1').api.Font.ColorIndex = 3
ws.range('D1').api.Font.ColorIndex = 3
ws.range('E1').api.Font.ColorIndex = 3
ws.range('G1:G100').api.Font.ColorIndex = 3
ws.range('A1:J100').api.HorizontalAlignment = -4108
ws.range('A2:A100').api.HorizontalAlignment = -4131
ws.range('A2').value = 'RTK trajectory'
ws.range('B2').value = str(round(rtk_length, 2))
row = 2

for file in files:
    n = len(files)

    file_str = file.split("\\")
    filename = file_str[-1]
    filename = filename[:-4]
    row = row + 1
    ws.range('A' + str(row)).value = filename
    """offset estimation"""
    shift_vector = track_shift_rtk2test(rtk_equalized_track, test_equalized_tracks[file])
    """Euclidean distance estimation"""
    # euclidean_dist, _, _ = track_euclidean_rtk2test(rtk_equalized_track, test_equalized_tracks[file])
    # self_euclidean_dist = track_euclidean_test2self(test_equalized_tracks[file])
    """Hausdorff distance estimation"""
    hausdorff_dist, _, _ = hausdorff_distance(rtk_equalized_track, test_equalized_tracks[file])

    """Convergence estimation"""
    self_dtw_dist = dtw_test2self(test_equalized_tracks[file])
    """Shifted trace estimation"""
    test_shifted_track = test_equalized_tracks[file] - shift_vector
    """DTW distance estimation---total deviation estimation"""
    dtw_deviation = dtw_rtk2test(rtk_equalized_track, test_equalized_tracks[file], similarity_or_deviation="deviation")
    # dtw_initial = dtw_rtk2test(rtk_equalized_track, test_equalized_tracks[file], similarity_or_deviation="initial")
    """Similarity estimation"""
    dtw_similarity = dtw_rtk2test(rtk_equalized_track, test_equalized_tracks[file],
                                  similarity_or_deviation="similarity")

    # euclidean_dist_shifted, _, _ = track_euclidean_rtk2test(rtk_equalized_track, test_shifted_track)
    # hausdorff_dist_shifted, _, _ = hausdorff_distance(rtk_equalized_track, test_shifted_track)
    """Trace length estimation"""
    len_track = track_length(test_equalized_tracks[file])
    loop_number = 3
    # write_data(filename, )
    ws.range('B' + str(row)).value = str(round(len_track / loop_number, 2))
    offset = np.linalg.norm(shift_vector)
    ws.range('C' + str(row)).value = str(round(offset, 2))
    ws.range('D' + str(row)).value = str(round(10 - self_dtw_dist, 2))
    ws.range('E' + str(row)).value = str(round(10 - dtw_similarity, 2))
    ws.range('F' + str(row)).value = str(round(dtw_deviation, 2))
    score = 100 - (self_dtw_dist ** 2 + dtw_similarity ** 2 + offset)
    ws.range('G' + str(row)).value = str(round(score, 2))
    # ws.range('H' + str(row)).value = str(round(hausdorff_dist_shifted, 2))
    # ws.range('I' + str(row)).value = str(round(dtw_dist_shifted, 2))
    # ws.range('J' + str(row)).value = str(round(self_dtw_dist, 2))
    # ws.range('M' + str(row)).value = str(round(dist_statistics[2], 2))+"%"
    # plt.subplot(1, n, i)
    plt.figure()
    plt.plot(rtk_equalized_track[:, 0], rtk_equalized_track[:, 1], 'r', linewidth=2, label='RTK_track')
    plt.plot(test_equalized_tracks[file][:, 0], test_equalized_tracks[file][:, 1], 'g', linewidth=2,
             label="test_track" + "\n" + "total Score: " + str(round(score, 2)) + "\n" + "Convergence score: " +
                   str(round(10 - self_dtw_dist, 2)) + "\n" + "Similarity score: " + str(round(10 - dtw_similarity, 2))
                   + "\n" + "offset: " + str(round(offset, 2)) + "m")
    # plt.plot(test_shifted_track[:, 0], test_shifted_track[:, 1], 'b', linewidth=2, label="shifted")
    plt.legend()
    plt.xlabel('East (m)')
    plt.ylabel('North (m)')
    plt.title(filename)
    plt.savefig(file_path + '\\' + filename + '.png')
    # plt.subplot(1, 2, 2)
    # b = plt.bar([1, 2, 3], np.array([hd19, hd16, hd1619]))
    # plt.xlabel('1-B19:Std;  2-B16:Std;  3-B19:B16')
    # plt.ylabel('Hausdorff Distance (m)')
    # plt.title('Hausdorff Distance of Three tracks')
wb.save()
# xw.App().quit()
plt.show(block=True)
